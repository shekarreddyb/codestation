$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    dotnet run --project src/KlipyPicker/KlipyPicker.csproj
    if ($LASTEXITCODE -ne 0) { throw 'Run failed.' }
} finally { Pop-Location }
