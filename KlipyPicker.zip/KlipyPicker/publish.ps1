param([ValidateSet('win-x64','win-arm64')] [string] $Runtime = 'win-x64')
$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    dotnet run --project tests/ContractChecks/ContractChecks.csproj -c Release
    if ($LASTEXITCODE -ne 0) { throw 'Contract checks failed.' }
    dotnet publish src/KlipyPicker/KlipyPicker.csproj -c Release -r $Runtime --self-contained true -o "release/$Runtime" -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true
    if ($LASTEXITCODE -ne 0) { throw 'Publish failed.' }
    Write-Host "Published to release/$Runtime. Run KlipyPicker.exe."
} finally { Pop-Location }
