# Validation record

Prepared 9 October 2026.

## Executed

- .NET SDK 10.0.100 obtained in the build environment.
- Contract check executable ran successfully: **9 checks passed**.
- Release WinForms compilation succeeded with **0 warnings and 0 errors** after correcting the .NET WinForms designer serialization annotation.
- Windows x64 framework-dependent publish succeeded. Final compilation includes preview eviction and keyboard-focus fixes.
- ZIP includes application source, build/run scripts, contract checks, README, this record, and the published Windows x64 application files.

## Contract checks

Validated native API response shape, result order, unchanged URL parameters, small-preview selection, static PNG sticker selection, content kind, pagination, failed responses, advertisement handling, and unsupported format rejection (grouped into nine assertions/checks).

Fixtures are synthetic and contain no API token. They validate parser behavior, not real provider availability.

## Still needs Windows and a real API key

- Running the executable and inspecting actual popup layout at different DPI scales.
- KLIPY Search/Trending responses for the user's testing key, authentication and real quota behavior.
- GIF animation and transparent sticker previews.
- Clipboard registered-GIF compatibility, temporary-file paste, and animation in Teams.
- Foreground restoration, global hotkey conflicts, clipboard contention and elevated destinations.
- Startup registration and DPAPI key persistence.

No Windows desktop or user API token was available in the build environment. No claim is made that the executable was launched, a real search was performed, or Teams accepted a GIF.
