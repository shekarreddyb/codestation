# Klipy Picker

A plain WinForms .NET 10 Windows tray utility. No UI frameworks, browser runtime, external packages, server, or database.

## Start on Windows

The ZIP includes a compiled Windows x64 build in `release/win-x64`. If **.NET 10 Windows Desktop Runtime** is already installed, run `KlipyPicker.exe` there. Keep its adjacent DLL/configuration files together. This bundled build is framework-dependent; use the self-contained publish instructions below to produce a version without the runtime prerequisite.

Install/use the .NET 10 SDK, extract this folder, then run from the project root:

```powershell
dotnet run --project src/KlipyPicker/KlipyPicker.csproj
```

Alternatively run `./run.ps1`. If your PowerShell policy blocks scripts, use the direct dotnet commands; changing corporate policy is not necessary.

Enter your **KLIPY API/app key** in Settings. This implementation uses the native `api/v1/{app_key}` API, not a bearer OAuth token or the Tenor-compatible V2 API. Do not send your key to anyone or put it in source code. It is encrypted using per-user Windows DPAPI under `%LocalAppData%/KlipyPicker/settings.json`.

Default shortcut: **Ctrl+Alt+G**. Closing the popup leaves the utility in the tray. Exit from the tray menu.

## Interface

- Three flat tabs: **All · Stickers · GIFs**. All means both implemented types, in labeled sections. It does not include clips, memes, or AI emojis in this version.
- One search input. Enter/Go submits; Trending uses an empty query.
- Small animated previews, modest spacing, and a restrained selected border.
- Click to select; double-click or Enter to insert.
- Down from search enters the grid. Arrow keys navigate, Shift+Enter copies the URL, Escape dismisses.
- Ctrl+Tab / Ctrl+Shift+Tab switches tabs, retaining the query.
- More loads the next page per visible content type. Each type retains its current query results/pagination until a different query replaces them. Up to 120 results per type; reopen or use a different query to release/reset results.
- Preview loads are limited to four at a time and start when tiles become visible. Images are disposed when the popup closes or results change; far-offscreen images are released while scrolling.
- Tray menu: open, settings, clipboard inspector, temporary-file cleanup, exit.

## Choose a paste mode in Settings

| Mode | Behavior | Limitation |
|---|---|---|
| URL (default) | Paste exact returned media URL | Link preview is controlled by the destination |
| Memory GIF | Encoded GIF stream in a registered `GIF` clipboard format | Experimental; Teams may ignore it. No temporary media file is written by this mode |
| Temporary file | Download GIF/PNG/JPEG to a temp file, place file-drop list on clipboard, request paste | Teams may treat it as an attachment or reject the paste; verify animation yourself |

The app cannot detect whether Teams actually consumed the clipboard. It does **not** silently claim success or automatically switch modes. If memory mode fails, choose Temporary file in Settings and retry. Copy URL always works independently of the selected insertion mode.

Temporary files are written only after a user selects content in Temporary file mode, under `%TEMP%/KlipyPicker`, with a 25 MiB size limit. A startup/manual cleanup pass removes files older than 24 hours unless the current clipboard references them. Files are not deleted immediately after Ctrl+V. No favorites/media cache is created. Settings/startup configuration are necessarily persisted even when media stays in memory.

Windows foreground restrictions and integrity boundaries can block automatic paste into elevated apps. The app verifies the recorded window is foreground and that modifier keys are released before injecting one Ctrl+V. If blocked, clipboard content stays available for manual paste. **It never presses Enter to send a message.**

## Clipboard inspector

1. Insert a GIF into a draft using Windows `Win+.`.
2. Right-click the Klipy Picker tray icon and choose **Inspect clipboard**.
3. Compare the native formats and stream sizes with the experimental Memory GIF mode.

The inspector reads format/type/size metadata without overwriting the clipboard or displaying clipboard text. This is a diagnostic tool, not proof that Windows avoids temporary storage. Virtual-file COM clipboard support has not been implemented in this version.

## Build and publish

```powershell
dotnet run --project tests/ContractChecks/ContractChecks.csproj -c Release
dotnet build src/KlipyPicker/KlipyPicker.csproj -c Release
dotnet publish src/KlipyPicker/KlipyPicker.csproj -c Release -r win-x64 --self-contained true -o release/win-x64
```

For single-file publishing use `./publish.ps1`, or add `-p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true` to the publish command. A self-contained build includes .NET and is larger. Single-file publishing may extract native runtime files; that is distinct from saving selected media. Startup opt-in records the executable's current location; turn it off/on if you move the release.

## Provider integration

Search/trending use the native GIF and Sticker endpoints and the documented `data.data` / `has_next` response structure. Responses select returned `xs/sm` previews and `hd/md` share variants, preferring GIF then PNG/JPEG. All URLs, query text, and provider ordering are retained. Unsupported media entries fail visibly rather than silently changing results. Animated WebP-only entries cannot be previewed by this implementation.

All typically costs two API requests per search/page, plus optional share-trigger calls on user selection. Testing quota is small; there is no search-as-you-type or polling. The customer ID is a random stable local identifier. Requests originate directly from the desktop app. Settings exposes content filtering, country, and selection reporting. Selection reporting calls `/share/{slug}` after copy or paste is requested; it cannot observe a sent Teams message. Disable it while diagnosing quota if needed and validate reporting semantics with KLIPY before release.

If the response contains advertising, this prototype rejects that page with a clear explanation. It has no ad renderer. Use an ad-free testing configuration; production integration requires implementing any delivery/advertising requirements applicable to the key. GIF downloads/clipboard sharing should be confirmed with KLIPY under its media delivery terms before distribution. Your willingness to use a temp file is separate from the provider agreement.

References, checked 9 October 2026:
- https://docs.klipy.com/gifs-api
- https://docs.klipy.com/stickers-api
- https://docs.klipy.com/
- https://klipy.com/support/api-terms
- https://learn.microsoft.com/en-us/windows/win32/dataxchg/using-the-clipboard

## Verification and known limits

See `VALIDATION.md` for actual checks performed. Real-key responses, visual layout, animated clipboard acceptance, foreground restoration, Windows startup, and Teams behavior require Windows validation. No token is bundled. The project is a functional prototype rather than a promise of universal paste compatibility.

Suggested Windows checks:
- Add your key, search punctuation/non-English terms, switch tabs, paginate, search rapidly, try invalid key/offline/quota responses.
- Check GIF animation and sticker transparency in both previews and the final Teams draft.
- Test Copy URL, Memory GIF, Temporary file, closed target, busy clipboard, elevated target, and hotkey conflicts.
- Inspect the clipboard after `Win+.` and after each app insertion mode.
- Open/dismiss repeatedly, scroll, resize, and test mixed-DPI monitors.
- Opt into startup only from the release executable; confirm startup and opt-out.

Not included: native Teams sticker semantics, virtual-file COM streams, clip playback, automatic updating, favorites, clipboard-history preservation, or guaranteed GIF animation in every app. There is no diagnostic log containing API requests or user clipboard data.
