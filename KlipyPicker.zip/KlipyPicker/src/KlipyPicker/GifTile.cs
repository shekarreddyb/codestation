namespace KlipyPicker;

internal sealed class GifTile : Panel
{
    public MediaItem Item { get; }
    private readonly PictureBox picture;
    private MemoryStream? stream;
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    public bool Selected { get; set; }
    public GifTile(MediaItem item, Action<GifTile, bool> activate)
    {
        SetStyle(ControlStyles.Selectable, true); TabStop = true;
        Padding = new(2);
        Item = item; Size = new(146, 138); Margin = new(5); BackColor = Color.FromArgb(245, 246, 248);
        AccessibleName = item.Title; AccessibleRole = AccessibleRole.PushButton; Cursor = Cursors.Hand;
        picture = new PictureBox { Dock = DockStyle.Fill, SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent, Padding = new(5) };
        var caption = new Label { Text = item.Title, Dock = DockStyle.Bottom, Height = 22, AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft, Padding = new(5, 0, 5, 0), Font = new("Segoe UI", 8) };
        Controls.Add(picture); Controls.Add(caption);
        foreach (Control child in Controls) { child.Click += (_, _) => activate(this, false); child.DoubleClick += (_, _) => activate(this, true); }
        Click += (_, _) => activate(this, false); DoubleClick += (_, _) => activate(this, true);
        Paint += (_, e) => { if (Selected) { using var pen = new Pen(Color.FromArgb(60, 105, 230), 3); e.Graphics.DrawRectangle(pen, 1, 1, Width - 3, Height - 3); } };
    }
    public bool HasImage => picture.Image is not null;
    public void ReleasePreview()
    {
        picture.Image?.Dispose(); picture.Image = null; stream?.Dispose(); stream = null;
    }
    public void SetBytes(byte[] bytes)
    {
        var nextStream = new MemoryStream(bytes);
        Image? nextImage = null;
        try
        {
            nextImage = Image.FromStream(nextStream);
            if ((long)nextImage.Width * nextImage.Height > 16_000_000) throw new InvalidDataException("Preview is too large.");
            picture.Image?.Dispose(); stream?.Dispose();
            stream = nextStream; picture.Image = nextImage;
        }
        catch { nextImage?.Dispose(); nextStream.Dispose(); throw; }
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing) { picture.Image?.Dispose(); picture.Image = null; stream?.Dispose(); }
        base.Dispose(disposing);
    }
}
