using System.Net;
using System.Net.Http.Json;

namespace KlipyPicker;

public sealed class KlipyClient : IDisposable
{
    private readonly HttpClient http = new() { Timeout = TimeSpan.FromSeconds(25) };
    public KlipyClient() => http.DefaultRequestHeaders.UserAgent.ParseAdd("KlipyPicker/0.1 (Windows)");

    public async Task<SearchPage> SearchAsync(AppSettings settings, ContentKind kind, string query, int page, CancellationToken ct)
    {
        var endpoint = string.IsNullOrWhiteSpace(query) ? "trending" : "search";
        var url = $"https://api.klipy.com/api/v1/{Uri.EscapeDataString(settings.Token)}/{Family(kind)}/{endpoint}" +
            $"?page={page}&per_page=24&customer_id={Uri.EscapeDataString(settings.CustomerId)}" +
            $"&locale={Uri.EscapeDataString(settings.Locale)}&content_filter={settings.Filter}";
        if (endpoint == "search") url += "&q=" + Uri.EscapeDataString(query);
        using var response = await http.GetAsync(url, ct);
        if (response.StatusCode == HttpStatusCode.TooManyRequests)
            throw new InvalidOperationException("Rate limit reached. Testing keys allow 100 API requests/hour. Wait before retrying; All uses two requests per page.");
        if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
            throw new InvalidOperationException("Key rejected. Check Settings and your KLIPY API key permissions.");
        if (!response.IsSuccessStatusCode) throw new InvalidOperationException($"KLIPY returned HTTP {(int)response.StatusCode}. Try again later.");
        return ResponseParser.Parse(await response.Content.ReadAsStringAsync(ct), kind);
    }

    public async Task<byte[]> MediaAsync(string url, int maxBytes, CancellationToken ct)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || uri.Scheme != "https")
            throw new InvalidDataException("Invalid media URL.");
        using var response = await http.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead, ct);
        if (!response.IsSuccessStatusCode) throw new InvalidOperationException($"Media returned HTTP {(int)response.StatusCode}.");
        if (response.Content.Headers.ContentLength > maxBytes) throw new InvalidDataException("Media exceeds the download size limit.");
        await using var input = await response.Content.ReadAsStreamAsync(ct);
        using var output = new MemoryStream();
        var buffer = new byte[16384];
        int count;
        while ((count = await input.ReadAsync(buffer, ct)) > 0)
        {
            if (output.Length + count > maxBytes) throw new InvalidDataException("Media exceeds the download size limit.");
            output.Write(buffer, 0, count);
        }
        return output.ToArray();
    }

    public async Task RegisterSelectionAsync(AppSettings settings, MediaItem item, string query)
    {
        if (string.IsNullOrEmpty(item.Slug)) return;
        try
        {
            using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
            using var response = await http.PostAsJsonAsync(
                $"https://api.klipy.com/api/v1/{Uri.EscapeDataString(settings.Token)}/{Family(item.Kind)}/share/{Uri.EscapeDataString(item.Slug)}",
                new { customer_id = settings.CustomerId, q = query }, timeout.Token);
            // Selection is the observable event; this is not a claim that Teams sent a message.
        }
        catch (Exception ex) when (ex is HttpRequestException or OperationCanceledException) { }
    }
    private static string Family(ContentKind kind) => kind == ContentKind.Gif ? "gifs" : "stickers";
    public void Dispose() => http.Dispose();
}
