using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;

namespace KlipyPicker;

public sealed class AppSettings
{
    public string ProtectedToken { get; set; } = "";
    [System.Text.Json.Serialization.JsonIgnore] public string Token { get; set; } = "";
    public string CustomerId { get; set; } = Guid.NewGuid().ToString();
    public string Locale { get; set; } = "in";
    public string Filter { get; set; } = "medium";
    public PasteMode Mode { get; set; } = PasteMode.Url;
    public Keys Hotkey { get; set; } = Keys.G;
    public bool Control { get; set; } = true;
    public bool Alt { get; set; } = true;
    public bool Shift { get; set; }
    public bool Startup { get; set; }
    public bool ReportSelections { get; set; } = true;
    public static string Folder => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KlipyPicker");
    public static string SettingsPath => Path.Combine(Folder, "settings.json");
    public string HotkeyLabel => $"{(Control ? "Ctrl+" : "")}{(Alt ? "Alt+" : "")}{(Shift ? "Shift+" : "")}{Hotkey}";

    public static AppSettings Load()
    {
        if (!File.Exists(SettingsPath)) return new();
        var s = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(SettingsPath)) ?? new();
        if (s.ProtectedToken.Length > 0) s.Token = Encoding.UTF8.GetString(Protect(Convert.FromBase64String(s.ProtectedToken), false));
        if (!Enum.IsDefined(s.Mode)) s.Mode = PasteMode.Url;
        if (s.Filter is not ("off" or "low" or "medium" or "high")) s.Filter = "medium";
        return s;
    }
    public void Save()
    {
        ProtectedToken = Token.Length == 0 ? "" : Convert.ToBase64String(Protect(Encoding.UTF8.GetBytes(Token), true));
        Directory.CreateDirectory(Folder);
        var temp = SettingsPath + ".tmp";
        File.WriteAllText(temp, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
        File.Move(temp, SettingsPath, true);
        using var key = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run");
        if (Startup) key.SetValue("KlipyPicker", $"\"{Application.ExecutablePath}\" --tray");
        else key.DeleteValue("KlipyPicker", false);
    }
    [StructLayout(LayoutKind.Sequential)] private struct Blob { public int Size; public IntPtr Data; }
    [DllImport("crypt32.dll", SetLastError = true)] private static extern bool CryptProtectData(ref Blob input, string? description, IntPtr entropy, IntPtr reserved, IntPtr prompt, uint flags, out Blob output);
    [DllImport("crypt32.dll", SetLastError = true)] private static extern bool CryptUnprotectData(ref Blob input, IntPtr description, IntPtr entropy, IntPtr reserved, IntPtr prompt, uint flags, out Blob output);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr memory);
    private static byte[] Protect(byte[] bytes, bool encrypt)
    {
        var input = new Blob { Size = bytes.Length, Data = Marshal.AllocHGlobal(bytes.Length) };
        Blob output = default;
        try
        {
            Marshal.Copy(bytes, 0, input.Data, bytes.Length);
            bool ok = encrypt ? CryptProtectData(ref input, null, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, 1, out output)
                : CryptUnprotectData(ref input, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, 1, out output);
            if (!ok) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
            var result = new byte[output.Size]; Marshal.Copy(output.Data, result, 0, result.Length); return result;
        }
        finally { Marshal.FreeHGlobal(input.Data); if (output.Data != IntPtr.Zero) LocalFree(output.Data); }
    }
}
