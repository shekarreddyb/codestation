using System.Collections.Specialized;
using System.Text;

namespace KlipyPicker;

internal static class ClipboardService
{
    public static string TempFolder => Path.Combine(Path.GetTempPath(), "KlipyPicker");
    public static async Task PrepareAsync(KlipyClient client, MediaItem item, PasteMode mode, CancellationToken ct)
    {
        if (mode == PasteMode.Url) { Clipboard.SetText(item.MediaUrl); return; }
        var bytes = await client.MediaAsync(item.MediaUrl, 25 * 1024 * 1024, ct);
        var gif = bytes.Length >= 6 && Encoding.ASCII.GetString(bytes, 0, 6) is "GIF87a" or "GIF89a";
        var png = bytes.Length >= 8 && bytes.AsSpan(0, 8).SequenceEqual(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 });
        var jpg = bytes.Length >= 3 && bytes[0] == 0xFF && bytes[1] == 0xD8 && bytes[2] == 0xFF;
        if (!gif && !png && !jpg) throw new InvalidDataException("The selected media is not a supported GIF, PNG, or JPEG.");
        if (mode == PasteMode.MemoryGif)
        {
            if (!gif) throw new InvalidOperationException("Memory GIF mode requires GIF content. Choose temporary file or URL for this item.");
            // Experimental registered format. It preserves bytes, but Teams may ignore it.
            using var stream = new MemoryStream(bytes);
            var data = new DataObject();
            data.SetData("GIF", false, stream);
            Clipboard.SetDataObject(data, true, 5, 100);
        }
        else
        {
            Directory.CreateDirectory(TempFolder);
            var path = Path.Combine(TempFolder, Guid.NewGuid().ToString("N") + (gif ? ".gif" : png ? ".png" : ".jpg"));
            await File.WriteAllBytesAsync(path, bytes, ct);
            var files = new StringCollection { path };
            Clipboard.SetFileDropList(files);
        }
    }
    public static void Cleanup()
    {
        if (!Directory.Exists(TempFolder)) return;
        // Keep files still referenced by the clipboard, regardless of age.
        var referenced = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        try { if (Clipboard.ContainsFileDropList()) foreach (string? path in Clipboard.GetFileDropList()) if (path is not null) referenced.Add(path); }
        catch (System.Runtime.InteropServices.ExternalException) { return; }
        foreach (var file in Directory.EnumerateFiles(TempFolder))
            try { if (!referenced.Contains(file) && File.GetLastWriteTimeUtc(file) < DateTime.UtcNow.AddDays(-1)) File.Delete(file); }
            catch (IOException) { } catch (UnauthorizedAccessException) { }
    }
    public static string Describe()
    {
        var data = Clipboard.GetDataObject();
        if (data is null) return "Clipboard is empty.";
        var lines = new List<string> { "Native clipboard formats (no clipboard changes):" };
        foreach (var format in data.GetFormats(false))
        {
            try
            {
                var value = data.GetData(format, false);
                var detail = value switch
                {
                    Stream s => $"stream, {(s.CanSeek ? s.Length.ToString() : "unknown")} bytes",
                    byte[] b => $"{b.Length} bytes",
                    string t => $"text, {t.Length} characters",
                    string[] f => $"{f.Length} file reference(s)",
                    _ => value?.GetType().Name ?? "unavailable"
                };
                lines.Add($"{format}: {detail}");
            }
            catch { lines.Add($"{format}: could not read"); }
        }
        return string.Join(Environment.NewLine, lines);
    }
}
