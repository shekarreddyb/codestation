using System.Runtime.InteropServices;

namespace KlipyPicker;

internal sealed class PickerForm : Form
{
    private AppSettings settings;
    private readonly KlipyClient client = new();
    private readonly NotifyIcon tray;
    private readonly TextBox search = new();
    private readonly FlowLayoutPanel tabs = new();
    private readonly FlowLayoutPanel grid = new();
    private readonly Label status = new();
    private readonly Button more;
    private readonly Button insert;
    private readonly ToolTip tips = new();
    private readonly List<GifTile> tiles = [];
    private readonly Dictionary<ContentKind, ContentState> states = new();
    private readonly SemaphoreSlim previews = new(4);
    private readonly HashSet<GifTile> requestedPreviews = [];
    private readonly System.Windows.Forms.Timer previewTimer = new() { Interval = 180 };
    private CancellationTokenSource? work;
    private CancellationTokenSource? insertion;
    private IntPtr target;
    private string activeTab = "All";
    private string submittedQuery = "";
    private int selected = -1;
    private int generation;
    private bool busy;
    private bool closing;
    private bool hotkeyRegistered;
    private bool firstOpen = true;
    private const int HotkeyId = 17;
    private sealed class ContentState
    {
        public string Query = "";
        public int Page;
        public bool HasNext;
        public List<MediaItem> Items = [];
        public string Error = "";
    }

    public PickerForm(AppSettings initial)
    {
        settings = initial;
        Text = "Klipy Picker"; Font = new("Segoe UI", 10); BackColor = Color.White;
        ClientSize = new(670, 600); MinimumSize = new(440, 380); StartPosition = FormStartPosition.Manual;
        ShowInTaskbar = false; KeyPreview = true; MaximizeBox = false;
        var shell = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Padding = new(14, 12, 14, 10) };
        shell.ColumnStyles.Add(new(SizeType.Percent, 100));
        shell.RowStyles.Add(new(SizeType.Absolute, 42)); shell.RowStyles.Add(new(SizeType.Absolute, 42)); shell.RowStyles.Add(new(SizeType.Percent, 100)); shell.RowStyles.Add(new(SizeType.Absolute, 56));
        Controls.Add(shell);
        var top = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3 };
        top.ColumnStyles.Add(new(SizeType.Percent, 100)); top.ColumnStyles.Add(new(SizeType.Absolute, 48)); top.ColumnStyles.Add(new(SizeType.Absolute, 72));
        search.PlaceholderText = "Search KLIPY"; search.BorderStyle = BorderStyle.FixedSingle; search.Dock = DockStyle.Fill; search.Margin = new(0, 4, 6, 0);
        var go = MinimalButton("Go", async () => await SearchAsync(false)); var options = MinimalButton("Settings", ShowSettings);
        top.Controls.Add(search, 0, 0); top.Controls.Add(go, 1, 0); top.Controls.Add(options, 2, 0); shell.Controls.Add(top, 0, 0);
        tabs.Dock = DockStyle.Fill; tabs.WrapContents = false;
        foreach (var name in new[] { "All", "Stickers", "GIFs" })
        {
            var b = MinimalButton(name, async () => { activeTab = name; UpdateTabs(); await SearchAsync(false, true); });
            b.Tag = name; b.Width = 88; tabs.Controls.Add(b);
        }
        var trending = MinimalButton("Trending", async () => { search.Clear(); await SearchAsync(false); }); trending.Width = 96; tabs.Controls.Add(trending);
        shell.Controls.Add(tabs, 0, 1);
        grid.Dock = DockStyle.Fill; grid.AutoScroll = true; grid.WrapContents = true; grid.BackColor = Color.White; grid.Padding = new(0, 4, 0, 4);
        shell.Controls.Add(grid, 0, 2);
        var footer = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 2 };
        footer.ColumnStyles.Add(new(SizeType.Percent, 100)); for (int i = 0; i < 3; i++) footer.ColumnStyles.Add(new(SizeType.Absolute, 90));
        status.AutoEllipsis = true; status.Dock = DockStyle.Fill; status.ForeColor = Color.FromArgb(95, 100, 110); status.TextAlign = ContentAlignment.MiddleLeft;
        more = MinimalButton("More", async () => await SearchAsync(true));
        var copy = MinimalButton("Copy URL", async () => await SelectAsync(true)); insert = MinimalButton("Insert", async () => await SelectAsync(false));
        footer.Controls.Add(status, 0, 0); footer.Controls.Add(more, 1, 0); footer.Controls.Add(copy, 2, 0); footer.Controls.Add(insert, 3, 0);
        var hint = new Label { Text = "↑↓←→ select  ·  Enter insert  ·  Shift+Enter copy  ·  Esc close  ·  Powered by KLIPY", Dock = DockStyle.Fill, ForeColor = Color.Gray, Font = new("Segoe UI", 8), TextAlign = ContentAlignment.MiddleLeft };
        footer.Controls.Add(hint, 0, 1); footer.SetColumnSpan(hint, 4); shell.Controls.Add(footer, 0, 3);
        tips.SetToolTip(insert, "Click once to select a tile; double-click or Enter to insert. Paste never sends your message.");
        tips.SetToolTip(options, "API key, paste mode, shortcut, startup and content filter");
        var menu = new ContextMenuStrip();
        menu.Items.Add("Open picker", null, (_, _) => OpenPicker());
        menu.Items.Add("Settings", null, (_, _) => { OpenPicker(); ShowSettings(); });
        menu.Items.Add("Inspect clipboard", null, (_, _) => InspectClipboard());
        menu.Items.Add("Clean old temporary files", null, (_, _) => { ClipboardService.Cleanup(); Notify("Old, unused temporary files cleaned."); });
        menu.Items.Add("Exit", null, (_, _) => { closing = true; Close(); Application.Exit(); });
        tray = new NotifyIcon { Icon = SystemIcons.Application, Text = "Klipy Picker", ContextMenuStrip = menu, Visible = true };
        tray.DoubleClick += (_, _) => OpenPicker();
        previewTimer.Tick += (_, _) => QueueVisiblePreviews();
        previewTimer.Start();
        UpdateTabs(); SetStatus("Type a search, or choose Trending.");
    }
    private static Button MinimalButton(string text, Action action)
    {
        var b = new Button { Text = text, FlatStyle = FlatStyle.Flat, BackColor = Color.White, ForeColor = Color.FromArgb(55, 60, 70), Height = 32, Margin = new(1, 2, 5, 2), Cursor = Cursors.Hand, TabStop = true };
        b.FlatAppearance.BorderSize = 0; b.FlatAppearance.MouseOverBackColor = Color.FromArgb(239, 242, 247);
        b.Click += (_, _) => action(); return b;
    }
    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        hotkeyRegistered = Register(settings);
    }
    protected override void OnHandleDestroyed(EventArgs e)
    {
        if (hotkeyRegistered) Native.UnregisterHotKey(Handle, HotkeyId);
        hotkeyRegistered = false; base.OnHandleDestroyed(e);
    }
    private bool Register(AppSettings s) => Native.RegisterHotKey(Handle, HotkeyId,
        0x4000u | (s.Control ? 2u : 0u) | (s.Alt ? 1u : 0u) | (s.Shift ? 4u : 0u), (uint)s.Hotkey);
    protected override void WndProc(ref Message m)
    {
        if (m.Msg == 0x0312 && m.WParam.ToInt32() == HotkeyId) { if (OwnedForms.Length > 0) return; if (Visible) Dismiss(); else OpenPicker(); return; }
        base.WndProc(ref m);
    }
    public void InitializeInTray() { _ = Handle; }
    public void OpenPicker()
    {
        if (busy) return;
        var foreground = Native.GetForegroundWindow();
        if (foreground != Handle) target = foreground;
        var bounds = Screen.FromPoint(Cursor.Position).WorkingArea;
        Location = new(Math.Clamp(Cursor.Position.X - Width / 2, bounds.Left, Math.Max(bounds.Left, bounds.Right - Width)), Math.Clamp(Cursor.Position.Y - 80, bounds.Top, Math.Max(bounds.Top, bounds.Bottom - Height)));
        Show(); Activate(); search.Focus(); search.SelectAll();
        if (firstOpen)
        {
            firstOpen = false;
            if (!hotkeyRegistered) BeginInvoke(new Action(() => MessageBox.Show(this, "The global shortcut is already in use. Choose another one in Settings.")));
            if (string.IsNullOrEmpty(settings.Token)) BeginInvoke(new Action(ShowSettings));
        }
        else if (states.Count > 0) { StartGeneration(); Render(); }
    }
    private void SetStatus(string message) { status.Text = message; tips.SetToolTip(status, message); }
    private void Notify(string text) { tray.BalloonTipTitle = "Klipy Picker"; tray.BalloonTipText = text; tray.ShowBalloonTip(4000); }
    private void UpdateTabs()
    {
        foreach (Button b in tabs.Controls) if (b.Tag is string name)
        { b.ForeColor = name == activeTab ? Color.FromArgb(50, 95, 215) : Color.FromArgb(105, 110, 120); b.Font = new("Segoe UI", 10, name == activeTab ? FontStyle.Bold : FontStyle.Regular); }
        insert.Text = settings.Mode == PasteMode.Url ? "Paste URL" : "Insert";
    }
    private void StartGeneration()
    {
        work?.Cancel(); work?.Dispose(); work = new(); generation++; ClearTiles();
    }
    private ContentKind[] Kinds() => activeTab switch { "GIFs" => [ContentKind.Gif], "Stickers" => [ContentKind.Sticker], _ => [ContentKind.Gif, ContentKind.Sticker] };
    private async Task SearchAsync(bool loadMore, bool switchOnly = false)
    {
        if (busy) return;
        if (string.IsNullOrWhiteSpace(settings.Token)) { SetStatus("Add your API key in Settings."); ShowSettings(); return; }
        var query = search.Text; // Preserve the user's query, including punctuation and spaces.
        if (switchOnly && states.Count == 0) { SetStatus("Type a search, or choose Trending."); return; }
        submittedQuery = query;
        StartGeneration(); int version = generation; var ct = work!.Token;
        SetStatus("Loading…"); more.Enabled = false;
        foreach (var kind in Kinds())
        {
            if (ct.IsCancellationRequested) return;
            if (!states.TryGetValue(kind, out var state) || state.Query != query)
            { state = new ContentState { Query = query }; states[kind] = state; }
            if (!loadMore && state.Page > 0 && state.Error.Length == 0) continue;
            if (loadMore && state.Page > 0 && !state.HasNext) continue;
            if (state.Items.Count >= 120) { state.HasNext = false; continue; }
            try
            {
                var result = await client.SearchAsync(settings, kind, query, state.Page + 1, ct);
                if (version != generation || ct.IsCancellationRequested) return;
                state.Items.AddRange(result.Items); state.Page++; state.HasNext = result.HasNext; state.Error = "";
            }
            catch (OperationCanceledException) { if (!ct.IsCancellationRequested && version == generation) state.Error = "Request timed out. Retry search."; else return; }
            catch (HttpRequestException) { state.Error = "Network request failed. Check your connection and KLIPY domain access."; }
            catch (Exception ex) when (ex is InvalidOperationException or InvalidDataException or System.Text.Json.JsonException)
            { state.Error = ex is System.Text.Json.JsonException ? "KLIPY returned invalid JSON." : ex.Message; }
            if (version != generation) return;
        }
        if (version == generation) Render();
    }
    private void Render()
    {
        ClearTiles(); grid.SuspendLayout();
        foreach (var kind in Kinds())
        {
            if (!states.TryGetValue(kind, out var state)) continue;
            if (activeTab == "All")
            {
                var header = new Label { Text = kind == ContentKind.Gif ? "GIFs" : "Stickers", Width = Math.Max(300, grid.ClientSize.Width - 30), Height = 28, Font = new("Segoe UI", 10, FontStyle.Bold), Margin = new(5, 6, 0, 0) };
                grid.Controls.Add(header); grid.SetFlowBreak(header, true);
            }
            if (state.Error.Length > 0)
            {
                var error = new Label { Text = state.Error, Width = Math.Max(300, grid.ClientSize.Width - 30), Height = 60, ForeColor = Color.Firebrick, Padding = new(5) };
                grid.Controls.Add(error); grid.SetFlowBreak(error, true);
            }
            foreach (var item in state.Items)
            {
                var tile = new GifTile(item, (t, activate) => { SelectTile(tiles.IndexOf(t)); t.Focus(); if (activate) _ = SelectAsync(false); });
                tiles.Add(tile); grid.Controls.Add(tile);
            }
        }
        grid.ResumeLayout(); SelectTile(tiles.Count > 0 ? 0 : -1);
        more.Enabled = Kinds().Any(k => states.TryGetValue(k, out var s) && s.HasNext && s.Items.Count < 120);
        var errors = Kinds().Where(states.ContainsKey).Select(k => states[k].Error).Where(x => x.Length > 0).ToArray();
        SetStatus(errors.Length > 0 ? "Some results failed. See the message above; submit again to retry." : tiles.Count == 0 ? "No results. Try another search." : $"{tiles.Count} results · {settings.Mode switch { PasteMode.Url => "URL", PasteMode.MemoryGif => "Memory GIF (experimental)", _ => "Temporary file" }}");
        QueueVisiblePreviews();
    }
    private void ClearTiles()
    {
        selected = -1; tiles.Clear(); requestedPreviews.Clear();
        while (grid.Controls.Count > 0) { var c = grid.Controls[0]; grid.Controls.Remove(c); c.Dispose(); }
    }
    private void QueueVisiblePreviews()
    {
        if (!Visible || work is null || work.IsCancellationRequested) return;
        var retainedArea = grid.ClientRectangle; retainedArea.Inflate(0, grid.ClientSize.Height);
        foreach (var tile in tiles)
            if (tile.HasImage && !tile.Bounds.IntersectsWith(retainedArea)) { tile.ReleasePreview(); requestedPreviews.Remove(tile); }
        foreach (var tile in tiles)
            if (!tile.IsDisposed && tile.Bounds.IntersectsWith(grid.ClientRectangle) && requestedPreviews.Add(tile))
                _ = LoadPreviewAsync(tile, work.Token, generation);
    }
    private async Task LoadPreviewAsync(GifTile tile, CancellationToken ct, int version)
    {
        bool entered = false;
        try
        {
            await previews.WaitAsync(ct); entered = true;
            if (tile.IsDisposed || !tile.Bounds.IntersectsWith(grid.ClientRectangle)) { requestedPreviews.Remove(tile); return; }
            var bytes = await client.MediaAsync(tile.Item.PreviewUrl, 3 * 1024 * 1024, ct);
            if (!ct.IsCancellationRequested && version == generation && !tile.IsDisposed) tile.SetBytes(bytes);
        }
        catch (OperationCanceledException) { }
        catch { if (!tile.IsDisposed && version == generation) tips.SetToolTip(tile, "Preview unavailable. You can still copy the media URL."); }
        finally { if (entered) previews.Release(); }
    }
    private void SelectTile(int index)
    {
        if (selected >= 0 && selected < tiles.Count) { tiles[selected].Selected = false; tiles[selected].Invalidate(); }
        selected = index;
        if (index >= 0 && index < tiles.Count) { tiles[index].Selected = true; tiles[index].Invalidate(); }
    }
    private async Task SelectAsync(bool copyOnly)
    {
        if (busy || selected < 0 || selected >= tiles.Count) return;
        var item = tiles[selected].Item; var capturedTarget = target; var query = submittedQuery;
        busy = true; insertion = new(); SetStatus("Preparing clipboard…");
        try
        {
            await ClipboardService.PrepareAsync(client, item, copyOnly ? PasteMode.Url : settings.Mode, insertion.Token);
            if (insertion.IsCancellationRequested) return;
            if (copyOnly) SetStatus("URL copied. Use Ctrl+V to paste.");
            else
            {
                Hide(); work?.Cancel(); ClearTiles();
                if (capturedTarget == IntPtr.Zero || !Native.IsWindow(capturedTarget)) { Notify("Copied. Original window is unavailable; paste manually."); return; }
                if (Native.IsIconic(capturedTarget)) Native.ShowWindow(capturedTarget, 9);
                Native.SetForegroundWindow(capturedTarget);
                for (int i = 0; i < 20 && (Native.ModifiersDown() || Native.GetForegroundWindow() != capturedTarget); i++) await Task.Delay(50);
                if (Native.GetForegroundWindow() != capturedTarget || Native.ModifiersDown() || !Native.Paste())
                    Notify("Copied. Automatic paste was blocked; paste manually.");
                else Notify("Paste requested. Check the draft; the utility cannot confirm that Teams accepted it.");
            }
            if (settings.ReportSelections) await client.RegisterSelectionAsync(settings, item, query);
        }
        catch (OperationCanceledException) { if (Visible) SetStatus("Insertion cancelled."); }
        catch (ExternalException) { if (Visible) SetStatus("Clipboard is busy. Try again."); }
        catch (HttpRequestException) { if (Visible) SetStatus("Media download failed. Try Copy URL."); }
        catch (Exception ex) when (ex is InvalidOperationException or InvalidDataException or IOException or UnauthorizedAccessException)
        { if (Visible) SetStatus(ex.Message); }
        finally { busy = false; insertion?.Dispose(); insertion = null; }
    }
    private void Dismiss()
    {
        insertion?.Cancel(); work?.Cancel(); generation++; Hide(); ClearTiles();
        if (target != IntPtr.Zero && Native.IsWindow(target)) Native.SetForegroundWindow(target);
    }
    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        if (keyData == Keys.Escape) { Dismiss(); return true; }
        if (keyData == (Keys.Control | Keys.Tab) || keyData == (Keys.Control | Keys.Shift | Keys.Tab))
        {
            var names = new[] { "All", "Stickers", "GIFs" }; int direction = keyData.HasFlag(Keys.Shift) ? -1 : 1;
            activeTab = names[(Array.IndexOf(names, activeTab) + direction + 3) % 3]; UpdateTabs(); _ = SearchAsync(false, true); return true;
        }
        if (search.Focused && keyData == Keys.Enter) { _ = SearchAsync(false); return true; }
        if (search.Focused && keyData == Keys.Down) { SelectTile(tiles.Count > 0 ? 0 : -1); if (tiles.Count > 0) tiles[0].Focus(); return true; }
        if (tiles.Any(t => t.ContainsFocus) && !busy)
        {
            if (keyData == Keys.Enter || keyData == (Keys.Shift | Keys.Enter)) { _ = SelectAsync(keyData.HasFlag(Keys.Shift)); return true; }
            int delta = keyData switch { Keys.Left => -1, Keys.Right => 1, Keys.Up => -Math.Max(1, grid.ClientSize.Width / 156), Keys.Down => Math.Max(1, grid.ClientSize.Width / 156), _ => 0 };
            if (delta != 0 && tiles.Count > 0) { SelectTile(Math.Clamp(selected + delta, 0, tiles.Count - 1)); grid.ScrollControlIntoView(tiles[selected]); tiles[selected].Focus(); return true; }
        }
        return base.ProcessCmdKey(ref msg, keyData);
    }
    private void ShowSettings()
    {
        if (busy) return;
        using var form = new SettingsForm(settings, next =>
        {
            if (hotkeyRegistered) Native.UnregisterHotKey(Handle, HotkeyId);
            if (!Register(next)) { hotkeyRegistered = Register(settings); MessageBox.Show(this, "That hotkey is unavailable. Your previous shortcut was retained."); return false; }
            hotkeyRegistered = true;
            try { next.Save(); }
            catch { Native.UnregisterHotKey(Handle, HotkeyId); hotkeyRegistered = Register(settings); MessageBox.Show(this, "Could not save settings. Check local profile and startup registry access."); return false; }
            settings = next; work?.Cancel(); states.Clear(); generation++; ClearTiles(); UpdateTabs(); SetStatus("Saved. Type a search or choose Trending."); return true;
        });
        form.ShowDialog(this);
    }
    private void InspectClipboard()
    {
        try
        {
            using var dialog = new Form { Text = "Clipboard inspector", ClientSize = new(560, 340), StartPosition = FormStartPosition.CenterScreen };
            dialog.Controls.Add(new TextBox { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both, Dock = DockStyle.Fill, Text = ClipboardService.Describe(), Font = new("Consolas", 10) }); dialog.ShowDialog();
        }
        catch (ExternalException) { Notify("Clipboard is busy. Try again."); }
    }
    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (!closing && e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; Dismiss(); return; }
        base.OnFormClosing(e);
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            closing = true; previewTimer.Stop(); previewTimer.Dispose(); work?.Cancel(); insertion?.Cancel();
            tray.Visible = false; tray.Dispose(); tips.Dispose(); ClearTiles(); client.Dispose();
        }
        base.Dispose(disposing);
    }
}
