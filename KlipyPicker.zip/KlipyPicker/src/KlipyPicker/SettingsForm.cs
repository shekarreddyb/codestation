namespace KlipyPicker;

internal sealed class SettingsForm : Form
{
    public SettingsForm(AppSettings settings, Func<AppSettings, bool> apply)
    {
        Text = "Klipy Picker settings"; ClientSize = new(480, 480); StartPosition = FormStartPosition.CenterParent;
        Font = new("Segoe UI", 10); BackColor = Color.White; FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false; MinimizeBox = false;
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new(20), ColumnCount = 2, AutoScroll = true };
        layout.ColumnStyles.Add(new(SizeType.Absolute, 135)); layout.ColumnStyles.Add(new(SizeType.Percent, 100)); Controls.Add(layout);
        int row = 0;
        void Add(string label, Control control) { layout.RowStyles.Add(new(SizeType.Absolute, 46)); layout.Controls.Add(new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left }, 0, row); control.Dock = DockStyle.Fill; control.Margin = new(0, 7, 0, 7); layout.Controls.Add(control, 1, row++); }
        var token = new TextBox { Text = settings.Token, UseSystemPasswordChar = true };
        var locale = new TextBox { Text = settings.Locale };
        var filter = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList }; filter.Items.AddRange(["off", "low", "medium", "high"]); filter.SelectedItem = settings.Filter;
        var mode = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList }; mode.Items.AddRange(["URL (reliable text)", "Memory GIF (experimental)", "Temporary file (try for Teams)"]); mode.SelectedIndex = (int)settings.Mode;
        var hotkey = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList }; for (int k = (int)Keys.A; k <= (int)Keys.Z; k++) hotkey.Items.Add((Keys)k); hotkey.SelectedItem = settings.Hotkey;
        var mods = new FlowLayoutPanel(); var ctrl = new CheckBox { Text = "Ctrl", Checked = settings.Control, AutoSize = true }; var alt = new CheckBox { Text = "Alt", Checked = settings.Alt, AutoSize = true }; var shift = new CheckBox { Text = "Shift", Checked = settings.Shift, AutoSize = true }; mods.Controls.AddRange([ctrl, alt, shift]);
        var startup = new CheckBox { Text = "Start at Windows sign-in", Checked = settings.Startup, AutoSize = true };
        var reports = new CheckBox { Text = "Report selections to KLIPY", Checked = settings.ReportSelections, AutoSize = true };
        Add("Testing API key", token); Add("Country code", locale); Add("Content filter", filter); Add("Paste mode", mode); Add("Hotkey letter", hotkey); Add("Modifiers", mods); Add("Startup", startup); Add("Selection events", reports);
        var save = new Button { Text = "Save", FlatStyle = FlatStyle.Flat }; Add("", save);
        save.Click += (_, _) =>
        {
            if (!ctrl.Checked && !alt.Checked) { MessageBox.Show(this, "Choose Ctrl or Alt for the global shortcut."); return; }
            if (locale.Text.Trim().Length != 2) { MessageBox.Show(this, "Enter a two-letter country code, such as in or us."); return; }
            var copy = new AppSettings { Token = token.Text.Trim(), CustomerId = settings.CustomerId, Locale = locale.Text.Trim().ToLowerInvariant(), Filter = filter.SelectedItem?.ToString() ?? "medium", Mode = (PasteMode)mode.SelectedIndex, Hotkey = (Keys)(hotkey.SelectedItem ?? Keys.G), Control = ctrl.Checked, Alt = alt.Checked, Shift = shift.Checked, Startup = startup.Checked, ReportSelections = reports.Checked };
            if (apply(copy)) { DialogResult = DialogResult.OK; Close(); }
        };
        AcceptButton = save;
    }
}
