namespace KlipyPicker;

internal static class Program
{
    [STAThread]
    static void Main(string[] args)
    {
        ApplicationConfiguration.Initialize();
        using var instance = new Mutex(true, @"Local\KlipyPicker-" + Environment.UserName, out var first);
        if (!first) { MessageBox.Show("Klipy Picker is already running. Use its tray icon or shortcut."); return; }
        AppSettings settings;
        try { settings = AppSettings.Load(); }
        catch { MessageBox.Show("Saved settings could not be read. Starting with defaults; re-enter your API key in Settings."); settings = new(); }
        try { ClipboardService.Cleanup(); } catch (IOException) { } catch (UnauthorizedAccessException) { }
        using var picker = new PickerForm(settings);
        picker.InitializeInTray();
        using var context = new ApplicationContext();
        picker.FormClosed += (_, _) => context.ExitThread();
        if (!args.Contains("--tray")) picker.OpenPicker();
        Application.Run(context);
    }
}
