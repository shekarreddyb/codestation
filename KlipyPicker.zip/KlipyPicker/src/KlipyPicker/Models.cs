using System.Text.Json;

namespace KlipyPicker;

public enum ContentKind { Gif, Sticker }
public enum PasteMode { Url, MemoryGif, TemporaryFile }
public sealed record MediaItem(string Id, string Slug, string Title, ContentKind Kind, string PreviewUrl, string MediaUrl);
public sealed record SearchPage(List<MediaItem> Items, bool HasNext);

public static class ResponseParser
{
    public static SearchPage Parse(string json, ContentKind kind)
    {
        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;
        if (!root.TryGetProperty("result", out var ok) || ok.ValueKind != JsonValueKind.True)
            throw new InvalidDataException("KLIPY did not return a successful result. Check your key and API access.");
        if (!root.TryGetProperty("data", out var data) || !data.TryGetProperty("data", out var rows) || rows.ValueKind != JsonValueKind.Array)
            throw new InvalidDataException("Unexpected KLIPY response shape. See API contract notes in README.");
        var items = new List<MediaItem>();
        foreach (var row in rows.EnumerateArray())
        {
            if (Text(row, "type") == "ad")
                throw new InvalidDataException("This key returned an advertisement. This native prototype cannot render ads; configure an ad-free testing key or implement the required ad renderer.");
            if (!row.TryGetProperty("file", out var file))
                throw new InvalidDataException("A KLIPY item has no supported media description.");
            var preview = Variant(file, ["xs", "sm", "md", "hd"]);
            var media = Variant(file, ["hd", "md", "sm", "xs"]);
            if (preview is null || media is null)
                throw new InvalidDataException("An item has no GIF/PNG/JPEG variant. Unsupported entries are not silently removed.");
            items.Add(new(Text(row, "id"), Text(row, "slug"), Text(row, "title"), kind, preview, media));
        }
        return new(items, data.TryGetProperty("has_next", out var next) && next.ValueKind == JsonValueKind.True);
    }

    private static string? Variant(JsonElement file, string[] sizes)
    {
        foreach (var size in sizes)
            if (file.TryGetProperty(size, out var formats))
                foreach (var format in new[] { "gif", "png", "jpg" })
                    if (formats.TryGetProperty(format, out var node))
                    {
                        var url = Text(node, "url");
                        if (Uri.TryCreate(url, UriKind.Absolute, out var uri) && uri.Scheme == "https") return url;
                    }
        return null;
    }
    private static string Text(JsonElement e, string key) => e.TryGetProperty(key, out var v) ? v.ToString() : "";
}
