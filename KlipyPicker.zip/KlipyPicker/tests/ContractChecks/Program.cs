using KlipyPicker;

string fixture = """
{"result":true,"data":{"data":[{"id":42,"slug":"a","title":"Test","file":{"hd":{"gif":{"url":"https://example.com/full.gif?tracking=a%2Bb"}},"xs":{"gif":{"url":"https://example.com/small.gif?x=1&y=2"}}}},{"id":43,"slug":"b","title":"Transparent","file":{"sm":{"png":{"url":"https://example.com/b.png"}}}}],"has_next":true}}
""";
var page = ResponseParser.Parse(fixture, ContentKind.Sticker);
Assert(page.Items.Count == 2 && page.HasNext, "Pagination and all entries retained");
Assert(page.Items[0].Id == "42" && page.Items[1].Id == "43", "Provider order retained");
Assert(page.Items[0].MediaUrl == "https://example.com/full.gif?tracking=a%2Bb", "URLs preserved byte-for-byte");
Assert(page.Items[0].PreviewUrl.Contains("small.gif"), "Small preview chosen");
Assert(page.Items[1].MediaUrl.EndsWith("b.png"), "Static stickers accepted");
Assert(page.Items.All(i => i.Kind == ContentKind.Sticker), "Content kind retained");
ExpectFailure("{\"result\":false}");
ExpectFailure("{\"result\":true,\"data\":{\"data\":[{\"type\":\"ad\"}]}}");
ExpectFailure("{\"result\":true,\"data\":{\"data\":[{\"file\":{\"hd\":{\"webp\":{\"url\":\"https://example.com/x.webp\"}}}}]}}");
Console.WriteLine("9 contract checks passed.");
void Assert(bool condition, string name) { if (!condition) throw new Exception(name); }
void ExpectFailure(string json) { try { ResponseParser.Parse(json, ContentKind.Gif); } catch (InvalidDataException) { return; } throw new Exception("Expected rejected contract"); }
