# VM Onboarding Workflow — Functional Documentation

## 1. Purpose

Automates moving a VM from build state to **operational** status through a
fixed, auditable sequence: security scans, change management (CR),
privilege removal, and ServiceNow status transition — with Kafka events
published at each milestone so downstream systems and dashboards can
follow along.

## 2. Triggers

A workflow starts when a request carrying a VM `hostname` arrives via:

| Channel | Contract |
|---|---|
| Kafka | message `{"hostname": "vm-123"}` on the request topic |
| REST | `POST /vms` body `{"hostname": "vm-123"}` → `202 Accepted` |

Both channels are idempotent: duplicate requests for the same hostname do
not create duplicate workflows; an in-flight workflow simply continues.

## 3. The flow (functional steps)

| # | Step | Behavior | Event published |
|---|---|---|---|
| 0 | Pre-checks | Validations before the flow proceeds. Failure marks the workflow failed with a reason. | — (configurable) |
| 1 | Trigger scans | Two scans submitted **in parallel** via scan APIs. | per scan: started/succeeded/failed |
| 2 | Await scan results | Poll the scan API until each scan reaches a terminal state; evidence is captured. | per scan: rescheduled while waiting, then succeeded/failed |
| 3 | Create CR | Only if **both scans are good**: a Change Request is created carrying the scan evidence. If scans are bad, the workflow terminates as failed (with event). | started/succeeded/failed |
| 4 | Await CR Implement | Poll change system until CR reaches *Implement*. A rejected/cancelled CR terminates the workflow as failed. | rescheduled/succeeded/failed |
| 5 | Remove build privileges | OS-specific API is chosen automatically (Linux/Windows/…). Evidence of removal is captured. | started/succeeded/failed |
| 6 | ServiceNow status change | Request server status change to *operational*. | — (configurable) |
| 7 | Await server status | Poll ServiceNow until the server reports *operational*. | rescheduled/succeeded/failed |
| 8 | Close CR | CR is closed with the privilege-removal evidence attached. Workflow complete. | started/succeeded/failed |

## 4. Event contract

Topic: `vm-workflow-events` (configurable). Payload:

```json
{
  "id": "vm-123",
  "activity": "await_cr_implement",
  "event": "started | succeeded | failed | rescheduled",
  "error": "present only on failed",
  "at": "2026-07-05T12:00:00Z"
}
```

Delivery is **at-least-once at best** (fire-and-forget). Consumers must
treat `(id, activity, event)` as the idempotency key. If specific events
become business-critical, the publisher can be swapped for a
transactional-outbox implementation without changing the flow.

## 5. Tracking & visibility

- `GET /vms/{hostname}` returns the live position, derived directly from
  the system of record, e.g.
  `{"at": "vm-onboarding/await_scans/[await_scan_a]", "done": false}`.
- Every log line carries `id` and the current position breadcrumb.
- The event stream provides the historical audit trail per activity.

## 6. Failure handling (functional view)

| Scenario | Behavior |
|---|---|
| External API transiently down | Step retried with exponential backoff (15s → 10m cap); workflow does not fail. |
| Scan reports bad results | Workflow terminates as failed; failure event published; CR is never created. |
| CR rejected or cancelled | Workflow terminates as failed with reason; failure event published. |
| Step keeps failing (10 consecutive attempts) | Workflow flagged exhausted; alert hook fires; operators remediate and re-queue. |
| Pod restart / deployment / crash | **All in-flight workflows resume automatically** at the exact step they were on. No manual recovery. |
| Duplicate request received | Ignored; existing workflow continues. |
| Operator data fix | Correcting the underlying record automatically moves the workflow to the corrected step on its next cycle. |

## 7. Non-functional characteristics

- Runs as multiple replicas; work is spread per-hostname, no coordinator.
- No workflow database of its own: progress is judged entirely from the
  existing system-of-record data (statuses, IDs, evidence fields).
- Waits (scan results, CR approval, status change) consume no resources —
  the VM is simply re-checked on schedule (30s–1m intervals, configurable
  per step).
