# vm-workflow

Code-configured workflow engine for moving VMs to operational status.
No Temporal, no workflow store, **no schema additions**: your existing
database remains the only source of truth, accessed exclusively through
your own retriever code. The workflow is defined as a tree of activities
and containers (Sequence / If / Switch / Parallel / While / Poll) that is
re-walked from the root on every cycle — which is why workflows resume
automatically after pod restarts.

See `vm-workflow-design.md` for the original design rationale (locks,
CAS writes, idempotency, edge cases — all still apply).

## The one rule

> Anything the workflow needs to remember must be derivable from your
> existing data (statuses, IDs, evidence fields).

- `Done()` and If/Switch/While conditions are pure: they read only the
  state your retriever loaded. No I/O, no volatile inputs.
- Activities follow **check → act → record**: query the external system
  first (crash-safe idempotency), act only if needed, persist through
  your own write code with conditional updates (`WHERE ... = expected`).
- Long waits are `Wait(duration)` reschedules, never sleeps.

## Layout

```
internal/dsl/         generic workflow tree (no DB dependency)
  node.go             Node[S], Activity, Poll
  containers.go       Sequence, If, Switch, Parallel (fork/join), While, PathTo
  events.go           Events decorator + Publisher interface (Kafka optional)
internal/engine/      stateless driver: your Lister/Loader + lock + tick loop
internal/lock/        Redis try-lock (+ local locker for tests)
internal/vmflow/      YOUR code: State, retrievers (SQL stubs), the 8-step Tree
internal/clients/     external API interfaces (Scan, Change, Privs, SNOW)
internal/ingest/      Kafka consumer (register→commit) + HTTP API + publisher
cmd/server/           wiring
```

## The flow as configured (internal/vmflow/tree.go)

```
pre_checks
trigger_scans        Parallel: submit scan A ∥ scan B        → events
await_scans          Parallel: poll A ∥ poll B               → events
scans_good?          If (reads persisted scan statuses)
├─ create_cr         with scan evidence                      → events
│  await_cr_implement  Poll; rejected/cancelled → fail       → events
│  remove_privs      Switch on os_type (linux/windows/...)   → events
│  request_snow_status
│  await_server_status Poll                                  → events
│  close_cr          with privilege-removal evidence         → events
└─ mark_failed_bad_scans                                     → events
```

Events publish `started | succeeded | failed | rescheduled` per wrapped
activity as `{id, activity, event, error?, at}`. Publishing is
fire-and-forget (observability-grade); for business-critical events,
implement `dsl.Publisher` over a transactional outbox in your database —
the tree doesn't change.

## Adapting to your environment (in order)

1. `vmflow.State` — rename/extend fields to mirror your real columns.
2. `vmflow.Retriever` — implement `Load`, `ListActive`, `Register`
   against your existing tables (SQL stubs show the intended shape).
3. `persist*` methods in `tree.go` — your conditional writes.
4. `internal/clients` — wire real API clients (reuse per-call ~15s
   context timeouts + cenkalti/backoff for transient 5xx).
5. Adjust the tree: add/remove activities, wrap/unwrap events.

## Run

```bash
go mod tidy && go test ./...
DATABASE_URL=... REDIS_ADDR=... KAFKA_BROKERS=... go run ./cmd/server

curl -X POST localhost:8080/vms -d '{"hostname":"vm-123"}'
curl localhost:8080/vms/vm-123    # → {"at":"vm-onboarding/await_scans/[...]","done":false}
```

## Restart & multi-pod semantics

- **Resume:** every cycle re-lists in-flight ids (your query), re-loads
  state (your retriever), re-walks the tree. A pod dying anywhere costs
  nothing — the walk lands where your data says the workflow stands.
- **Multi-pod:** per-hostname Redis try-lock spreads work; losing the
  race is a silent skip. Locks are efficiency; your conditional writes
  are correctness.
- **In-memory only:** per-id "not before" times and retry counters.
  Losing them on restart merely causes one early re-check per workflow.
- **Poison workflows:** after `MaxAttempts` consecutive failures,
  `OnExhausted` fires — persist a failure there so `ListActive` drops it.
