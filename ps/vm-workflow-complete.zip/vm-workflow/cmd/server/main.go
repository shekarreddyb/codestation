// Single binary running ingestion (HTTP + optional Kafka), the engine
// loop, and event publishing. The only storage touched is YOUR existing
// database via the vmflow.Retriever — this program adds no tables.
package main

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"

	"vmworkflow/internal/dsl"
	"vmworkflow/internal/engine"
	"vmworkflow/internal/ingest"
	"vmworkflow/internal/lock"
	"vmworkflow/internal/vmflow"
)

func main() {
	log := slog.New(slog.NewJSONHandler(os.Stdout, nil))
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	// --- Config (env) ---
	dsn := envOr("DATABASE_URL", "postgres://user:pass@localhost:5433/db") // YOUR existing DB
	redisAddr := envOr("REDIS_ADDR", "localhost:6379")
	kafkaBrokers := os.Getenv("KAFKA_BROKERS")
	eventsTopic := envOr("EVENTS_TOPIC", "vm-workflow-events")
	httpAddr := envOr("HTTP_ADDR", ":8080")

	// --- Your existing database + retrievers ---
	db, err := pgxpool.New(ctx, dsn)
	if err != nil {
		log.Error("db connect", "err", err)
		os.Exit(1)
	}
	defer db.Close()
	retriever := &vmflow.Retriever{DB: db}

	// --- Event publisher: Kafka if configured, else drop ---
	var pub dsl.Publisher = dsl.NopPublisher{}
	if kafkaBrokers != "" {
		kp, err := ingest.NewKafkaPublisher(strings.Split(kafkaBrokers, ","))
		if err != nil {
			log.Error("kafka publisher", "err", err)
			os.Exit(1)
		}
		defer kp.Close()
		pub = kp
	}
	events := dsl.Events[*vmflow.State]{
		Pub:   pub,
		Topic: eventsTopic,
		ID:    func(s *vmflow.State) string { return s.Hostname },
		Log:   log,
	}

	// --- The workflow tree (code-configured) ---
	tree := vmflow.Tree(vmflow.Deps{
		// Scan / Change / Privs / SNOW: wire your real API clients here.
		Persist: retriever,
		Events:  events,
		Log:     log,
	})

	// --- Engine ---
	eng := &engine.Engine[*vmflow.State]{
		Tree:   tree,
		Loader: retriever,
		Lister: retriever,
		Locker: lock.NewRedisLocker(redisAddr, os.Getenv("REDIS_PASSWORD")),
		Log:    log,
		Cfg: engine.Config{
			LockTTL:     2 * time.Minute,
			TickEvery:   5 * time.Second,
			Parallelism: 8,
			RetryBase:   15 * time.Second,
			RetryMax:    10 * time.Minute,
			MaxAttempts: 10,
		},
		OnExhausted: func(ctx context.Context, id string, lastErr error) {
			// Persist terminal failure in YOUR data (so ListActive drops it)
			// and/or publish an alerting event here.
			log.Error("workflow exhausted retries", "id", id, "err", lastErr)
		},
	}
	done := make(chan struct{})
	go func() {
		defer close(done)
		eng.Run(ctx)
	}()

	// --- Kafka ingestion (optional) ---
	if kafkaBrokers != "" {
		consumer, err := ingest.NewKafkaConsumer(
			strings.Split(kafkaBrokers, ","),
			envOr("KAFKA_TOPIC", "vm-workflow"),
			envOr("KAFKA_GROUP", "vm-workflow-workers"),
			retriever, log)
		if err != nil {
			log.Error("kafka init", "err", err)
			os.Exit(1)
		}
		go consumer.Run(ctx)
	}

	// --- HTTP ingestion + status ---
	api := &ingest.HTTPServer{
		Registrar: retriever, Loader: retriever, Tree: tree, Engine: eng, Log: log,
	}
	srv := &http.Server{Addr: httpAddr, Handler: api.Routes()}
	go func() {
		log.Info("http listening", "addr", httpAddr)
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Error("http server", "err", err)
			stop()
		}
	}()

	<-ctx.Done()
	log.Info("shutting down")
	shutCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	_ = srv.Shutdown(shutCtx)
	<-done
	log.Info("bye")
}

func envOr(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}
