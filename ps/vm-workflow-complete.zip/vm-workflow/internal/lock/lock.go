// Package lock provides the distributed try-lock used to spread work
// across pods. The lock is an efficiency mechanism (avoid duplicate
// walks) — correctness rests on idempotent activities (check → act →
// record) and conditional writes in YOUR persistence code.
package lock

import (
	"context"
	"errors"
	"time"

	"github.com/bsm/redislock"
	"github.com/redis/go-redis/v9"
)

// Locker is a try-lock: failing to acquire is a normal skip, not an error.
type Locker interface {
	// TryAcquire returns (release, true, nil) on success,
	// (nil, false, nil) if someone else holds the lock.
	TryAcquire(ctx context.Context, key string, ttl time.Duration) (release func(context.Context), ok bool, err error)
}

// --- Redis ------------------------------------------------------------------

type RedisLocker struct {
	client *redislock.Client
}

func NewRedisLocker(addr, password string) *RedisLocker {
	rdb := redis.NewClient(&redis.Options{Addr: addr, Password: password})
	return &RedisLocker{client: redislock.New(rdb)}
}

func (l *RedisLocker) TryAcquire(ctx context.Context, key string, ttl time.Duration) (func(context.Context), bool, error) {
	lk, err := l.client.Obtain(ctx, key, ttl, nil) // nil = no retry: try-lock
	if errors.Is(err, redislock.ErrNotObtained) {
		return nil, false, nil
	}
	if err != nil {
		return nil, false, err
	}
	return func(c context.Context) { _ = lk.Release(c) }, true, nil
}

// --- Local (single-pod dev/tests) --------------------------------------------

type LocalLocker struct {
	held map[string]struct{}
	mu   chan struct{} // 1-buffered mutex usable with context
}

func NewLocalLocker() *LocalLocker {
	l := &LocalLocker{held: map[string]struct{}{}, mu: make(chan struct{}, 1)}
	l.mu <- struct{}{}
	return l
}

func (l *LocalLocker) TryAcquire(ctx context.Context, key string, _ time.Duration) (func(context.Context), bool, error) {
	select {
	case <-l.mu:
	case <-ctx.Done():
		return nil, false, ctx.Err()
	}
	defer func() { l.mu <- struct{}{} }()
	if _, taken := l.held[key]; taken {
		return nil, false, nil
	}
	l.held[key] = struct{}{}
	release := func(context.Context) {
		<-l.mu
		delete(l.held, key)
		l.mu <- struct{}{}
	}
	return release, true, nil
}
