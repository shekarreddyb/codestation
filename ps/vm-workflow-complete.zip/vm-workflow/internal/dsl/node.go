// Package dsl provides a code-configured workflow tree: activities plus
// container nodes (Sequence, If, Parallel, While, Poll), interpreted by
// re-walking the tree from the root on every engine cycle.
//
// The DSL is generic over YOUR state type S. It has no database schema,
// no storage, and performs no writes of its own. You supply:
//
//   - a retriever (engine.Loader) that builds S from your existing tables
//   - Done/condition functions that judge progress from S
//   - activities whose side effects update YOUR tables with YOUR code
//
// The one rule that makes this restart-safe with no workflow store:
//
//	ANYTHING THE WORKFLOW NEEDS TO REMEMBER MUST BE DERIVABLE FROM S,
//	i.e. from your existing data (evidence fields, statuses, CR numbers).
//
//   - Done() is pure: no I/O. A fresh pod re-walks the tree and lands
//     exactly where the workflow left off, because S says so.
//   - If/While conditions read only S. If a decision comes from volatile
//     data (an API response), an Activity persists the decision to your
//     tables first; the condition reads it back on the next walk.
//   - Run() performs ONE unit of work and returns; long waits are
//     expressed as Result.RescheduleAfter, never sleeps.
package dsl

import (
	"context"
	"time"
)

// Result of one unit of work.
type Result struct {
	// RescheduleAfter > 0 means "not ready — walk me again after this
	// delay" (polling, waiting). Zero means progress was made and the
	// engine may walk again on the next tick.
	RescheduleAfter time.Duration
}

// Progress: work advanced; re-walk soon.
var Progress = Result{}

// Wait: nothing to do yet; re-walk after d.
func Wait(d time.Duration) Result { return Result{RescheduleAfter: d} }

// Node is anything walkable: a leaf activity or a container.
type Node[S any] interface {
	Name() string
	// Done reports whether this node has completed — judged ONLY from S.
	Done(s S) bool
	// Run performs one unit of work for the first incomplete part of this
	// node. Not called when Done(s) is true.
	Run(ctx context.Context, s S) (Result, error)
}

// ---------------------------------------------------------------------------
// Activity — leaf node: one idempotent unit of work (check → act → record).
// ---------------------------------------------------------------------------

type activity[S any] struct {
	name string
	done func(S) bool
	run  func(context.Context, S) (Result, error)
}

// Activity builds a leaf node. done judges completion from your state;
// run should follow check → act → record: query the external system first
// (crash-safe idempotency), act only if needed, persist the outcome to
// your tables via your own code.
func Activity[S any](name string, done func(S) bool,
	run func(context.Context, S) (Result, error)) Node[S] {
	return &activity[S]{name: name, done: done, run: run}
}

func (a *activity[S]) Name() string { return a.name }
func (a *activity[S]) Done(s S) bool { return a.done(s) }
func (a *activity[S]) Run(ctx context.Context, s S) (Result, error) {
	return a.run(ctx, s)
}

// ---------------------------------------------------------------------------
// Poll — an activity that checks an external system once per walk.
// ---------------------------------------------------------------------------

// Poll: done judges completion from S. check queries the external system;
// when the awaited thing is ready it must persist the outcome to your
// tables (making done true on the next walk) and return ready=true.
// When not ready, Poll returns Wait(every) — that reschedule IS the loop.
func Poll[S any](name string, every time.Duration, done func(S) bool,
	check func(context.Context, S) (ready bool, err error)) Node[S] {
	return Activity[S](name, done, func(ctx context.Context, s S) (Result, error) {
		ready, err := check(ctx, s)
		if err != nil {
			return Progress, err
		}
		if !ready {
			return Wait(every), nil
		}
		return Progress, nil
	})
}
