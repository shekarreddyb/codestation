package dsl

import (
	"context"
	"encoding/json"
	"log/slog"
	"time"
)

// Publisher abstracts the event sink so publishing stays swappable:
// fire-and-forget Kafka now; a transactional-outbox implementation later
// if some events become business-critical — the tree definition and the
// decorator don't change.
type Publisher interface {
	Publish(ctx context.Context, topic string, key, value []byte) error
}

// Event payload published around wrapped activities.
// Consumers should key idempotency on (id, activity, event) — delivery
// is at-least-once at best; duplicates are possible.
type Event struct {
	ID       string    `json:"id"` // e.g. hostname
	Activity string    `json:"activity"`
	Event    string    `json:"event"` // started|succeeded|failed|rescheduled
	Error    string    `json:"error,omitempty"`
	At       time.Time `json:"at"`
}

// Events is configured once per workflow, then used to wrap any activity
// that should publish. Publishing failures never fail the workflow —
// they are logged and the activity outcome stands (observability-grade
// delivery; use an outbox Publisher for stronger guarantees).
type Events[S any] struct {
	Pub   Publisher
	Topic string
	ID    func(S) string // how to identify the workflow subject (hostname)
	Log   *slog.Logger
}

type eventedNode[S any] struct {
	ev    Events[S]
	inner Node[S]
}

// Wrap decorates a node: publishes started before Run, then
// succeeded / failed / rescheduled after, based on the outcome.
// Done() passes through untouched — no events on skipped walks.
func (ev Events[S]) Wrap(inner Node[S]) Node[S] {
	return &eventedNode[S]{ev: ev, inner: inner}
}

func (n *eventedNode[S]) Name() string { return n.inner.Name() }
func (n *eventedNode[S]) Done(s S) bool { return n.inner.Done(s) }

func (n *eventedNode[S]) Run(ctx context.Context, s S) (Result, error) {
	n.emit(ctx, s, "started", nil)
	res, err := n.inner.Run(ctx, s)
	switch {
	case err != nil:
		n.emit(ctx, s, "failed", err)
	case res.RescheduleAfter > 0:
		n.emit(ctx, s, "rescheduled", nil)
	default:
		n.emit(ctx, s, "succeeded", nil)
	}
	return res, err
}

func (n *eventedNode[S]) emit(ctx context.Context, s S, kind string, cause error) {
	e := Event{
		ID:       n.ev.ID(s),
		Activity: n.inner.Name(),
		Event:    kind,
		At:       time.Now().UTC(),
	}
	if cause != nil {
		e.Error = cause.Error()
	}
	payload, _ := json.Marshal(e)
	if err := n.ev.Pub.Publish(ctx, n.ev.Topic, []byte(e.ID), payload); err != nil {
		n.ev.Log.Warn("event publish failed",
			"id", e.ID, "activity", e.Activity, "event", kind, "err", err)
	}
}

// NopPublisher drops all events (tests, local runs without Kafka).
type NopPublisher struct{}

func (NopPublisher) Publish(context.Context, string, []byte, []byte) error { return nil }
