package dsl

import (
	"context"
	"errors"
	"log/slog"
	"sync"
	"testing"
	"time"
)

// fake state: a mutable map standing in for "your existing database".
type st struct {
	mu   sync.Mutex
	done map[string]bool
	log  []string
}

func (s *st) mark(k string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.done[k] = true
	s.log = append(s.log, k)
}
func (s *st) is(k string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.done[k]
}

func act(name string) Node[*st] {
	return Activity[*st](name,
		func(s *st) bool { return s.is(name) },
		func(_ context.Context, s *st) (Result, error) {
			s.mark(name)
			return Progress, nil
		})
}

// drive walks the tree until done, like the engine would, with a step cap.
func drive(t *testing.T, n Node[*st], s *st) {
	t.Helper()
	for i := 0; i < 50; i++ {
		if n.Done(s) {
			return
		}
		if _, err := n.Run(context.Background(), s); err != nil {
			t.Fatalf("walk %d: %v", i, err)
		}
	}
	t.Fatal("tree did not complete in 50 walks")
}

func TestSequenceRunsInOrder(t *testing.T) {
	s := &st{done: map[string]bool{}}
	drive(t, Sequence[*st]("root", act("a"), act("b"), act("c")), s)
	want := []string{"a", "b", "c"}
	for i, w := range want {
		if s.log[i] != w {
			t.Fatalf("order = %v, want %v", s.log, want)
		}
	}
}

func TestIfTakesBranchAndSkips(t *testing.T) {
	s := &st{done: map[string]bool{}}
	tree := Sequence[*st]("root",
		If[*st]("gate", func(s *st) bool { return true }, act("then"), act("else")),
		If[*st]("skip", func(s *st) bool { return false }, act("never"), nil),
		act("after"),
	)
	drive(t, tree, s)
	if !s.is("then") || s.is("else") || s.is("never") || !s.is("after") {
		t.Fatalf("branching wrong: %v", s.done)
	}
}

func TestParallelForkJoin(t *testing.T) {
	s := &st{done: map[string]bool{}}
	tree := Sequence[*st]("root",
		Parallel[*st]("scans", act("scan_a"), act("scan_b")),
		act("join"), // must not run before both scans
	)
	// One walk should run BOTH parallel children.
	if _, err := tree.Run(context.Background(), s); err != nil {
		t.Fatal(err)
	}
	if !s.is("scan_a") || !s.is("scan_b") {
		t.Fatalf("parallel didn't run both branches: %v", s.done)
	}
	if s.is("join") {
		t.Fatal("join ran before parallel completed a walk cycle")
	}
	drive(t, tree, s)
	if !s.is("join") {
		t.Fatal("join never ran")
	}
}

func TestParallelPartialFailureRetriesOnlyFailedBranch(t *testing.T) {
	s := &st{done: map[string]bool{}}
	bBlown := false
	failOnce := Activity[*st]("flaky_b",
		func(s *st) bool { return s.is("flaky_b") },
		func(_ context.Context, s *st) (Result, error) {
			if !bBlown {
				bBlown = true
				return Progress, errors.New("boom")
			}
			s.mark("flaky_b")
			return Progress, nil
		})
	tree := Parallel[*st]("p", act("ok_a"), failOnce)

	_, err := tree.Run(context.Background(), s)
	if err == nil {
		t.Fatal("expected joined error from failed branch")
	}
	if !s.is("ok_a") {
		t.Fatal("sibling branch should have completed despite failure")
	}
	// Second walk: only the failed branch reruns.
	if _, err := tree.Run(context.Background(), s); err != nil {
		t.Fatal(err)
	}
	if !tree.Done(s) {
		t.Fatal("parallel not done after retry")
	}
	// ok_a ran exactly once.
	count := 0
	for _, l := range s.log {
		if l == "ok_a" {
			count++
		}
	}
	if count != 1 {
		t.Fatalf("ok_a ran %d times, want 1", count)
	}
}

func TestPollReschedulesUntilReady(t *testing.T) {
	s := &st{done: map[string]bool{}}
	checks := 0
	p := Poll[*st]("wait", 30*time.Second,
		func(s *st) bool { return s.is("wait") },
		func(_ context.Context, s *st) (bool, error) {
			checks++
			if checks < 3 {
				return false, nil
			}
			s.mark("wait")
			return true, nil
		})
	res, _ := p.Run(context.Background(), s)
	if res.RescheduleAfter != 30*time.Second {
		t.Fatalf("want 30s reschedule, got %v", res.RescheduleAfter)
	}
	p.Run(context.Background(), s)
	res, _ = p.Run(context.Background(), s)
	if res.RescheduleAfter != 0 || !p.Done(s) {
		t.Fatalf("poll should be done after ready, res=%v", res)
	}
}

// capture publisher for event tests
type capture struct {
	mu   sync.Mutex
	msgs []string
}

func (c *capture) Publish(_ context.Context, _ string, _, v []byte) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.msgs = append(c.msgs, string(v))
	return nil
}

func TestEventsWrapPublishesOutcomes(t *testing.T) {
	s := &st{done: map[string]bool{}}
	cap := &capture{}
	ev := Events[*st]{
		Pub: cap, Topic: "t",
		ID:  func(*st) string { return "vm-1" },
		Log: slog.Default(),
	}
	n := ev.Wrap(act("step"))
	n.Run(context.Background(), s)

	if len(cap.msgs) != 2 {
		t.Fatalf("want started+succeeded, got %d msgs: %v", len(cap.msgs), cap.msgs)
	}
	for _, want := range []string{"started", "succeeded"} {
		found := false
		for _, m := range cap.msgs {
			if contains(m, want) && contains(m, "vm-1") && contains(m, "step") {
				found = true
			}
		}
		if !found {
			t.Fatalf("missing %q event in %v", want, cap.msgs)
		}
	}
}

func TestPathToBreadcrumb(t *testing.T) {
	s := &st{done: map[string]bool{}}
	tree := Sequence[*st]("root", act("a"),
		If[*st]("gate", func(*st) bool { return true }, act("b"), nil))
	if got := PathTo(tree, s); got != "root/a" {
		t.Fatalf("PathTo = %q, want root/a", got)
	}
	s.mark("a")
	if got := PathTo(tree, s); got != "root/gate/b" {
		t.Fatalf("PathTo = %q, want root/gate/b", got)
	}
}

func contains(haystack, needle string) bool {
	return len(haystack) >= len(needle) && index(haystack, needle) >= 0
}
func index(h, n string) int {
	for i := 0; i+len(n) <= len(h); i++ {
		if h[i:i+len(n)] == n {
			return i
		}
	}
	return -1
}
