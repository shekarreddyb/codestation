package dsl

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"time"
)

// ---------------------------------------------------------------------------
// Sequence — children run in order; done when all children are done.
// ---------------------------------------------------------------------------

type sequence[S any] struct {
	name     string
	children []Node[S]
}

func Sequence[S any](name string, children ...Node[S]) Node[S] {
	return &sequence[S]{name: name, children: children}
}

func (n *sequence[S]) Name() string { return n.name }

func (n *sequence[S]) Done(s S) bool {
	for _, c := range n.children {
		if !c.Done(s) {
			return false
		}
	}
	return true
}

// Run executes the first not-done child (one unit of work per walk).
func (n *sequence[S]) Run(ctx context.Context, s S) (Result, error) {
	for _, c := range n.children {
		if !c.Done(s) {
			return c.Run(ctx, s)
		}
	}
	return Progress, nil
}

// ---------------------------------------------------------------------------
// If — condition judged from S (must be stable/persisted, see package doc).
// els may be nil ("skip when false").
// ---------------------------------------------------------------------------

type ifNode[S any] struct {
	name string
	cond func(S) bool
	then Node[S]
	els  Node[S]
}

func If[S any](name string, cond func(S) bool, then, els Node[S]) Node[S] {
	return &ifNode[S]{name: name, cond: cond, then: then, els: els}
}

func (n *ifNode[S]) Name() string { return n.name }

func (n *ifNode[S]) pick(s S) Node[S] {
	if n.cond(s) {
		return n.then
	}
	return n.els
}

func (n *ifNode[S]) Done(s S) bool {
	branch := n.pick(s)
	return branch == nil || branch.Done(s)
}

func (n *ifNode[S]) Run(ctx context.Context, s S) (Result, error) {
	branch := n.pick(s)
	if branch == nil {
		return Progress, nil
	}
	return branch.Run(ctx, s)
}

// ---------------------------------------------------------------------------
// Switch — n-way If (e.g. per-OS privilege removal across many OS types).
// ---------------------------------------------------------------------------

type Case[S any] struct {
	When func(S) bool
	Then Node[S]
}

type switchNode[S any] struct {
	name    string
	cases   []Case[S]
	deflt   Node[S] // may be nil
}

func Switch[S any](name string, deflt Node[S], cases ...Case[S]) Node[S] {
	return &switchNode[S]{name: name, cases: cases, deflt: deflt}
}

func (n *switchNode[S]) Name() string { return n.name }

func (n *switchNode[S]) pick(s S) Node[S] {
	for _, c := range n.cases {
		if c.When(s) {
			return c.Then
		}
	}
	return n.deflt
}

func (n *switchNode[S]) Done(s S) bool {
	branch := n.pick(s)
	return branch == nil || branch.Done(s)
}

func (n *switchNode[S]) Run(ctx context.Context, s S) (Result, error) {
	branch := n.pick(s)
	if branch == nil {
		return Progress, nil
	}
	return branch.Run(ctx, s)
}

// ---------------------------------------------------------------------------
// Parallel — fork/join. Every walk runs ALL not-done children concurrently
// (one unit of work each); done when ALL children are done (the join).
//
// Each branch's progress must be independently derivable from S — e.g.
// scan A's and scan B's IDs/statuses are separate fields in your data.
// Branch failures don't stop sibling branches within a walk; errors are
// joined so the engine can back off and retry the failed branches only
// (the succeeded ones will be Done on the next walk).
// ---------------------------------------------------------------------------

type parallel[S any] struct {
	name     string
	children []Node[S]
}

func Parallel[S any](name string, children ...Node[S]) Node[S] {
	return &parallel[S]{name: name, children: children}
}

func (n *parallel[S]) Name() string { return n.name }

func (n *parallel[S]) Done(s S) bool {
	for _, c := range n.children {
		if !c.Done(s) {
			return false
		}
	}
	return true
}

func (n *parallel[S]) Run(ctx context.Context, s S) (Result, error) {
	type outcome struct {
		res Result
		err error
	}
	var (
		wg  sync.WaitGroup
		mu  sync.Mutex
		outs []outcome
	)
	for _, c := range n.children {
		if c.Done(s) {
			continue
		}
		wg.Add(1)
		go func(child Node[S]) {
			defer wg.Done()
			res, err := child.Run(ctx, s)
			if err != nil {
				err = fmt.Errorf("%s: %w", child.Name(), err)
			}
			mu.Lock()
			outs = append(outs, outcome{res, err})
			mu.Unlock()
		}(c)
	}
	wg.Wait()

	// Aggregate: any error → join; reschedule → smallest positive wait
	// (re-walk as soon as the earliest branch wants attention).
	var errs []error
	var minWait time.Duration
	for _, o := range outs {
		if o.err != nil {
			errs = append(errs, o.err)
		}
		if d := o.res.RescheduleAfter; d > 0 && (minWait == 0 || d < minWait) {
			minWait = d
		}
	}
	if len(errs) > 0 {
		return Result{RescheduleAfter: minWait}, errors.Join(errs...)
	}
	return Result{RescheduleAfter: minWait}, nil
}

// ---------------------------------------------------------------------------
// While — repeats body while cond(S) is true; done when cond is false.
//
// Loop progress MUST live in your data (a counter, a list of processed
// items): both cond and the body's Done functions read it. A body that is
// fully Done while cond is still true indicates iteration state wasn't
// advanced/reset in your data — that walk returns an error rather than
// spinning forever.
// ---------------------------------------------------------------------------

type whileNode[S any] struct {
	name string
	cond func(S) bool
	body Node[S]
}

func While[S any](name string, cond func(S) bool, body Node[S]) Node[S] {
	return &whileNode[S]{name: name, cond: cond, body: body}
}

func (n *whileNode[S]) Name() string { return n.name }
func (n *whileNode[S]) Done(s S) bool { return !n.cond(s) }

func (n *whileNode[S]) Run(ctx context.Context, s S) (Result, error) {
	if n.body.Done(s) {
		return Progress, fmt.Errorf(
			"while %q: body is done but condition still true — iteration state not advanced in your data", n.name)
	}
	return n.body.Run(ctx, s)
}

// ---------------------------------------------------------------------------
// PathTo — breadcrumb of the first incomplete node ("root/if/remove_privs").
// Use it for status endpoints and logs; costs nothing, derived from S.
// ---------------------------------------------------------------------------

func PathTo[S any](n Node[S], s S) string {
	if n.Done(s) {
		return n.Name() + "/done"
	}
	switch t := n.(type) {
	case *sequence[S]:
		for _, c := range t.children {
			if !c.Done(s) {
				return t.name + "/" + PathTo(c, s)
			}
		}
	case *ifNode[S]:
		if b := t.pick(s); b != nil {
			return t.name + "/" + PathTo(b, s)
		}
	case *switchNode[S]:
		if b := t.pick(s); b != nil {
			return t.name + "/" + PathTo(b, s)
		}
	case *parallel[S]:
		out := t.name + "/["
		first := true
		for _, c := range t.children {
			if !c.Done(s) {
				if !first {
					out += ","
				}
				out += PathTo(c, s)
				first = false
			}
		}
		return out + "]"
	case *whileNode[S]:
		return t.name + "/" + PathTo(t.body, s)
	}
	return n.Name()
}
