// Package clients defines the external API surfaces the workflow calls.
// Interfaces keep activities unit-testable with fakes; the HTTP stubs are
// placeholders — swap in your real request/response shapes and auth.
package clients

import "context"

type ScanAPI interface {
	// FindExisting returns an in-flight scan ID for (hostname, kind), or
	// "" if none — the crash-safety CHECK before submitting.
	FindExisting(ctx context.Context, hostname, kind string) (string, error)
	Submit(ctx context.Context, hostname, kind string) (scanID string, err error)
	// Result returns (status, evidence). status: pending|complete|failed.
	Result(ctx context.Context, scanID string) (status, evidence string, err error)
}

type ChangeAPI interface {
	FindExisting(ctx context.Context, hostname string) (crNumber string, err error)
	Create(ctx context.Context, hostname, scanEvidence string) (crNumber string, err error)
	State(ctx context.Context, crNumber string) (string, error) // new|approval|implement|rejected|cancelled|closed
	Close(ctx context.Context, crNumber, privsEvidence string) error
}

type PrivsAPI interface {
	HasBuildPrivs(ctx context.Context, hostname, osType string) (bool, error)
	// Remove returns evidence of the removal for the CR close-out.
	Remove(ctx context.Context, hostname, osType string) (evidence string, err error)
}

type SNOWAPI interface {
	RequestStatusChange(ctx context.Context, hostname, target string) error
	ServerStatus(ctx context.Context, hostname string) (string, error)
}

// NOTE: HTTP implementations intentionally omitted from the skeleton —
// wire your real clients here (reuse the retry/backoff pattern:
// per-call context timeout ~15s + cenkalti/backoff for transient 5xx,
// backoff.Permanent for 4xx). Fakes for tests live in vmflow tests.
