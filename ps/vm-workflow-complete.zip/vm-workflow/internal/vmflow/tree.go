package vmflow

import (
	"context"
	"fmt"
	"log/slog"
	"time"

	"vmworkflow/internal/clients"
	"vmworkflow/internal/dsl"
)

// Deps carries the external API clients and your persistence writes.
// Writes go through YOUR code (Persist) so no schema is imposed.
type Deps struct {
	Scan    clients.ScanAPI
	Change  clients.ChangeAPI
	Privs   clients.PrivsAPI
	SNOW    clients.SNOWAPI
	Persist *Retriever // reuse; add write methods to it as needed
	Events  dsl.Events[*State]
	Log     *slog.Logger
}

// Tree defines the full onboarding flow in code. Node granularity mirrors
// your 8 steps; every event-publishing step is wrapped with ev.Wrap.
//
//	pre_checks
//	trigger_scans (parallel: scan A + scan B)      → events
//	await_scans   (parallel polls)                 → events
//	gate: scans good?
//	  ├─ create_cr (with scan evidence)            → events
//	  │  await_cr_implement                        → events
//	  │  remove_privs (switch on OS type)          → events
//	  │  request_snow_status
//	  │  await_server_status                       → events
//	  │  close_cr (with privs evidence)            → events
//	  └─ mark_failed (scans bad → terminal, event) → events
func Tree(d Deps) dsl.Node[*State] {
	ev := d.Events

	return dsl.Sequence[*State]("vm-onboarding",

		dsl.Activity[*State]("pre_checks",
			func(s *State) bool { return s.PreChecksPassed },
			func(ctx context.Context, s *State) (dsl.Result, error) {
				// Run your validations; persist pass/fail via your code.
				// Failing validations should mark the workflow failed in
				// your data (Lister stops returning it) and may publish.
				return dsl.Progress, d.persistPreChecks(ctx, s)
			}),

		// --- 1. Trigger scans (parallel) + events -------------------------
		dsl.Parallel[*State]("trigger_scans",
			ev.Wrap(dsl.Activity[*State]("submit_scan_a",
				func(s *State) bool { return s.ScanAID != "" },
				d.submitScan("a"))),
			ev.Wrap(dsl.Activity[*State]("submit_scan_b",
				func(s *State) bool { return s.ScanBID != "" },
				d.submitScan("b"))),
		),

		// --- 2. Wait for scan results + events ----------------------------
		dsl.Parallel[*State]("await_scans",
			ev.Wrap(dsl.Poll[*State]("await_scan_a", 30*time.Second,
				func(s *State) bool { return terminalScan(s.ScanAStatus) },
				d.checkScan("a"))),
			ev.Wrap(dsl.Poll[*State]("await_scan_b", 30*time.Second,
				func(s *State) bool { return terminalScan(s.ScanBStatus) },
				d.checkScan("b"))),
		),

		// --- 3..8 gated on scan outcome ------------------------------------
		// Condition reads persisted scan statuses — stable across restarts.
		dsl.If[*State]("scans_good",
			func(s *State) bool { return s.ScansGood() },

			dsl.Sequence[*State]("proceed",

				// 3. Create CR with scan evidence + event
				ev.Wrap(dsl.Activity[*State]("create_cr",
					func(s *State) bool { return s.CRNumber != "" },
					func(ctx context.Context, s *State) (dsl.Result, error) {
						// CHECK: a CR may exist from a crashed run — query
						// the change system by hostname before creating.
						cr, err := d.Change.FindExisting(ctx, s.Hostname)
						if err != nil {
							return dsl.Progress, err
						}
						if cr == "" {
							cr, err = d.Change.Create(ctx, s.Hostname, s.ScanEvidence)
							if err != nil {
								return dsl.Progress, err
							}
						}
						return dsl.Progress, d.persistCR(ctx, s, cr)
					})),

				// 4. Wait for CR to reach Implement + event
				ev.Wrap(dsl.Poll[*State]("await_cr_implement", time.Minute,
					func(s *State) bool { return s.CRState == "implement" },
					func(ctx context.Context, s *State) (bool, error) {
						state, err := d.Change.State(ctx, s.CRNumber)
						if err != nil {
							return false, err
						}
						if state == "rejected" || state == "cancelled" {
							// Terminal CR: persist failure so ListActive
							// drops it; error surfaces a failed event.
							_ = d.persistFailed(ctx, s, "CR "+state)
							return false, fmt.Errorf("CR %s was %s", s.CRNumber, state)
						}
						if state == s.CRState {
							return false, nil // unchanged — keep polling
						}
						return state == "implement", d.persistCRState(ctx, s, state)
					})),

				// 5. Remove build privileges, per-OS API + event
				ev.Wrap(dsl.Switch[*State]("remove_privs",
					/* default: */ dsl.Activity[*State]("remove_privs_unknown_os",
						func(s *State) bool { return s.BuildPrivsRemoved },
						func(ctx context.Context, s *State) (dsl.Result, error) {
							return dsl.Progress, fmt.Errorf("unknown os_type %q", s.OSType)
						}),
					dsl.Case[*State]{
						When: func(s *State) bool { return s.OSType == "linux" },
						Then: dsl.Activity[*State]("remove_privs_linux",
							func(s *State) bool { return s.BuildPrivsRemoved },
							d.removePrivs(clientsOSLinux)),
					},
					dsl.Case[*State]{
						When: func(s *State) bool { return s.OSType == "windows" },
						Then: dsl.Activity[*State]("remove_privs_windows",
							func(s *State) bool { return s.BuildPrivsRemoved },
							d.removePrivs(clientsOSWindows)),
					},
				)),

				// 6. Request server status change in ServiceNow
				dsl.Activity[*State]("request_snow_status",
					func(s *State) bool { return s.SNOWStatusRequested },
					func(ctx context.Context, s *State) (dsl.Result, error) {
						if err := d.SNOW.RequestStatusChange(ctx, s.Hostname, "operational"); err != nil {
							return dsl.Progress, err
						}
						return dsl.Progress, d.persistSNOWRequested(ctx, s)
					}),

				// 7. Poll for server status + event
				ev.Wrap(dsl.Poll[*State]("await_server_status", 30*time.Second,
					func(s *State) bool { return s.ServerStatus == "operational" },
					func(ctx context.Context, s *State) (bool, error) {
						status, err := d.SNOW.ServerStatus(ctx, s.Hostname)
						if err != nil || status == s.ServerStatus {
							return false, err
						}
						return status == "operational", d.persistServerStatus(ctx, s, status)
					})),

				// 8. Close CR with privilege-removal evidence + event
				ev.Wrap(dsl.Activity[*State]("close_cr",
					func(s *State) bool { return s.CRState == "closed" },
					func(ctx context.Context, s *State) (dsl.Result, error) {
						if err := d.Change.Close(ctx, s.CRNumber, s.PrivsEvidence); err != nil {
							return dsl.Progress, err
						}
						return dsl.Progress, d.persistCRState(ctx, s, "closed")
					})),
			),

			// else: scans bad → terminal failure + event
			ev.Wrap(dsl.Activity[*State]("mark_failed_bad_scans",
				func(s *State) bool { return s.Failed },
				func(ctx context.Context, s *State) (dsl.Result, error) {
					return dsl.Progress, d.persistFailed(ctx, s, "scan results not acceptable")
				})),
		),
	)
}

func terminalScan(status string) bool { return status == "complete" || status == "failed" }

// ---------------------------------------------------------------------------
// Activity bodies — thin: call the API, persist through YOUR code.
// ---------------------------------------------------------------------------

type osKind string

const (
	clientsOSLinux   osKind = "linux"
	clientsOSWindows osKind = "windows"
)

func (d Deps) submitScan(kind string) func(context.Context, *State) (dsl.Result, error) {
	return func(ctx context.Context, s *State) (dsl.Result, error) {
		// CHECK first: crash-safe idempotency.
		id, err := d.Scan.FindExisting(ctx, s.Hostname, kind)
		if err != nil {
			return dsl.Progress, err
		}
		if id == "" {
			if id, err = d.Scan.Submit(ctx, s.Hostname, kind); err != nil {
				return dsl.Progress, err
			}
		}
		return dsl.Progress, d.persistScanSubmitted(ctx, s, kind, id)
	}
}

func (d Deps) checkScan(kind string) func(context.Context, *State) (bool, error) {
	return func(ctx context.Context, s *State) (bool, error) {
		id := s.ScanAID
		if kind == "b" {
			id = s.ScanBID
		}
		status, evidence, err := d.Scan.Result(ctx, id)
		if err != nil {
			return false, err
		}
		if !terminalScan(status) {
			return false, nil // keep polling
		}
		return true, d.persistScanResult(ctx, s, kind, status, evidence)
	}
}

func (d Deps) removePrivs(os osKind) func(context.Context, *State) (dsl.Result, error) {
	return func(ctx context.Context, s *State) (dsl.Result, error) {
		// CHECK: privileges may already be gone from a crashed run.
		has, err := d.Privs.HasBuildPrivs(ctx, s.Hostname, string(os))
		if err != nil {
			return dsl.Progress, err
		}
		evidence := s.PrivsEvidence
		if has {
			if evidence, err = d.Privs.Remove(ctx, s.Hostname, string(os)); err != nil {
				return dsl.Progress, err
			}
		}
		return dsl.Progress, d.persistPrivsRemoved(ctx, s, evidence)
	}
}

// ---------------------------------------------------------------------------
// Persistence — YOUR write code against YOUR existing tables. Each write
// should be conditional on expected prior state (WHERE ... = expected)
// so a stale lock holder can never corrupt anything. Stubs to fill in.
// ---------------------------------------------------------------------------

func (d Deps) persistPreChecks(ctx context.Context, s *State) error            { return nil }
func (d Deps) persistScanSubmitted(ctx context.Context, s *State, kind, id string) error { return nil }
func (d Deps) persistScanResult(ctx context.Context, s *State, kind, status, evidence string) error { return nil }
func (d Deps) persistCR(ctx context.Context, s *State, crNumber string) error  { return nil }
func (d Deps) persistCRState(ctx context.Context, s *State, state string) error { return nil }
func (d Deps) persistPrivsRemoved(ctx context.Context, s *State, evidence string) error { return nil }
func (d Deps) persistSNOWRequested(ctx context.Context, s *State) error        { return nil }
func (d Deps) persistServerStatus(ctx context.Context, s *State, status string) error { return nil }
func (d Deps) persistFailed(ctx context.Context, s *State, reason string) error { return nil }
