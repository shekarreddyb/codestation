// Package vmflow is YOUR part: the workflow state, the retrievers that
// build it from your EXISTING database (no schema additions), and the
// tree definition. Everything in this package is meant to be edited.
package vmflow

import (
	"context"

	"github.com/jackc/pgx/v5/pgxpool"
)

// State is the read-model the tree walks over. It is rebuilt fresh from
// your existing tables on every walk (never cached), so every Done() and
// If-condition below reflects what your database actually says.
//
// Populate it from wherever your data already lives — the field list
// below matches the 8-step flow; rename/extend to your real columns.
type State struct {
	Hostname string
	OSType   string // e.g. "linux", "windows" — must already be in your data

	PreChecksPassed bool

	// Two scans submitted in parallel; each branch independently derivable.
	ScanAID, ScanAStatus string // "" | submitted | complete | failed
	ScanBID, ScanBStatus string
	ScanEvidence         string // evidence blob/reference from your tables

	CRNumber string
	CRState  string // "" | new | approval | implement | closed | rejected

	BuildPrivsRemoved bool
	PrivsEvidence     string // evidence collected during removal

	SNOWStatusRequested bool
	ServerStatus        string // e.g. "" | pending | operational

	Failed       bool   // your data's terminal-failure marker
	FailedReason string
}

func (s *State) ScansGood() bool {
	return s.ScanAStatus == "complete" && s.ScanBStatus == "complete"
}
func (s *State) ScansFailed() bool {
	return s.ScanAStatus == "failed" || s.ScanBStatus == "failed"
}

// ---------------------------------------------------------------------------
// Retrievers: YOUR custom code. The engine only ever touches your data
// through these two + whatever writes your activities perform.
// ---------------------------------------------------------------------------

type Retriever struct {
	DB *pgxpool.Pool // or whatever client your existing database needs
}

// Load builds State for one hostname from your existing tables.
// Replace the query with your real schema — joins, evidence fields, etc.
func (r *Retriever) Load(ctx context.Context, hostname string) (*State, error) {
	s := &State{Hostname: hostname}
	// EXAMPLE ONLY — adapt to your existing schema:
	//
	// err := r.DB.QueryRow(ctx, `
	//     SELECT v.os_type,
	//            v.pre_checks_passed,
	//            COALESCE(sa.scan_id,''), COALESCE(sa.status,''),
	//            COALESCE(sb.scan_id,''), COALESCE(sb.status,''),
	//            COALESCE(v.scan_evidence,''),
	//            COALESCE(v.cr_number,''), COALESCE(v.cr_state,''),
	//            v.build_privs_removed, COALESCE(v.privs_evidence,''),
	//            v.snow_status_requested, COALESCE(v.server_status,''),
	//            v.failed, COALESCE(v.failed_reason,'')
	//     FROM vms v
	//     LEFT JOIN scans sa ON sa.hostname = v.hostname AND sa.kind = 'a'
	//     LEFT JOIN scans sb ON sb.hostname = v.hostname AND sb.kind = 'b'
	//     WHERE v.hostname = $1`, hostname).Scan(&s.OSType, ...)
	return s, nil
}

// ListActive returns hostnames with an in-flight workflow, judged from
// your existing data: registered for onboarding, not yet operational,
// not marked failed. This query IS your work queue — no extra tables.
func (r *Retriever) ListActive(ctx context.Context) ([]string, error) {
	// EXAMPLE ONLY — adapt to your existing schema:
	//
	// rows, err := r.DB.Query(ctx, `
	//     SELECT hostname FROM vms
	//     WHERE requested = true
	//       AND server_status <> 'operational'
	//       AND failed = false
	//     ORDER BY updated_at
	//     LIMIT 200`)
	return nil, nil
}

// Register is called by ingestion (Kafka/REST) when a request arrives.
// Write to YOUR tables however you already mark a VM as requested —
// must be idempotent (duplicate deliveries are normal).
func (r *Retriever) Register(ctx context.Context, hostname string) error {
	// EXAMPLE ONLY:
	// _, err := r.DB.Exec(ctx,
	//     `UPDATE vms SET requested = true WHERE hostname = $1`, hostname)
	return nil
}
