package ingest

import (
	"context"
	"encoding/json"
	"log/slog"
	"net/http"
	"time"

	"vmworkflow/internal/dsl"
	"vmworkflow/internal/engine"
	"vmworkflow/internal/vmflow"
)

type HTTPServer struct {
	Registrar Registrar
	Loader    engine.Loader[*vmflow.State]
	Tree      dsl.Node[*vmflow.State]
	Engine    *engine.Engine[*vmflow.State]
	Log       *slog.Logger
}

func (h *HTTPServer) Routes() *http.ServeMux {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /vms", h.createVM)
	mux.HandleFunc("GET /vms/{hostname}", h.getVM)
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})
	return mux
}

// POST /vms {"hostname":"vm-123"} → 202. Registration via YOUR code is
// the whole job; the engine loop picks it up. We also kick one walk
// immediately (detached from the request context) so stage 1 starts now.
func (h *HTTPServer) createVM(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Hostname string `json:"hostname"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil || body.Hostname == "" {
		http.Error(w, `{"error":"hostname required"}`, http.StatusBadRequest)
		return
	}
	if err := h.Registrar.Register(r.Context(), body.Hostname); err != nil {
		h.Log.Error("register", "hostname", body.Hostname, "err", err)
		http.Error(w, `{"error":"internal"}`, http.StatusInternalServerError)
		return
	}
	go func(hostname string) {
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		h.Engine.Process(ctx, hostname)
	}(body.Hostname)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusAccepted)
	_ = json.NewEncoder(w).Encode(map[string]string{
		"hostname": body.Hostname,
		"status":   "/vms/" + body.Hostname,
	})
}

// GET /vms/{hostname} → current position derived live from YOUR data:
// load state through the retriever, report the tree breadcrumb.
func (h *HTTPServer) getVM(w http.ResponseWriter, r *http.Request) {
	hostname := r.PathValue("hostname")
	s, err := h.Loader.Load(r.Context(), hostname)
	if err != nil {
		h.Log.Error("load", "hostname", hostname, "err", err)
		http.Error(w, `{"error":"internal"}`, http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"hostname": hostname,
		"at":       dsl.PathTo(h.Tree, s),
		"done":     h.Tree.Done(s),
		"failed":   s.Failed,
		"reason":   s.FailedReason,
	})
}
