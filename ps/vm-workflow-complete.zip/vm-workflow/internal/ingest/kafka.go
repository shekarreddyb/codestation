package ingest

import (
	"context"
	"encoding/json"
	"log/slog"

	"github.com/twmb/franz-go/pkg/kgo"
)

// Registrar is YOUR code that marks a hostname as requested in your
// existing data. Must be idempotent (duplicate deliveries are normal).
type Registrar interface {
	Register(ctx context.Context, hostname string) error
}

// KafkaConsumer ingests {"hostname":"vm-123"}. It does the minimum:
// register via your code, then commit. Workflow execution happens in the
// engine loop — never inside the consumer (rebalance storms).
//
// Offsets commit ONLY after Register succeeds (at-least-once). Committing
// first would be the one way to silently lose a request — don't.
type KafkaConsumer struct {
	client    *kgo.Client
	registrar Registrar
	log       *slog.Logger
}

type vmMessage struct {
	Hostname string `json:"hostname"`
}

func NewKafkaConsumer(brokers []string, topic, group string, reg Registrar, log *slog.Logger) (*KafkaConsumer, error) {
	client, err := kgo.NewClient(
		kgo.SeedBrokers(brokers...),
		kgo.ConsumerGroup(group),
		kgo.ConsumeTopics(topic),
		kgo.DisableAutoCommit(),
	)
	if err != nil {
		return nil, err
	}
	return &KafkaConsumer{client: client, registrar: reg, log: log}, nil
}

func (k *KafkaConsumer) Run(ctx context.Context) {
	defer k.client.Close()
	for {
		fetches := k.client.PollFetches(ctx)
		if ctx.Err() != nil {
			return
		}
		if errs := fetches.Errors(); len(errs) > 0 {
			for _, e := range errs {
				k.log.Error("kafka fetch", "topic", e.Topic, "err", e.Err)
			}
			continue
		}
		var toCommit []*kgo.Record
		fetches.EachRecord(func(r *kgo.Record) {
			var msg vmMessage
			if err := json.Unmarshal(r.Value, &msg); err != nil || msg.Hostname == "" {
				k.log.Warn("skipping malformed message", "offset", r.Offset, "err", err)
				toCommit = append(toCommit, r) // poison message: commit past it
				return
			}
			if err := k.registrar.Register(ctx, msg.Hostname); err != nil {
				k.log.Error("register failed, will redeliver", "hostname", msg.Hostname, "err", err)
				return // no commit → redelivered; Register is idempotent
			}
			k.log.Info("workflow registered", "hostname", msg.Hostname)
			toCommit = append(toCommit, r)
		})
		if len(toCommit) > 0 {
			if err := k.client.CommitRecords(ctx, toCommit...); err != nil {
				k.log.Error("commit offsets", "err", err)
			}
		}
	}
}

// --- Event publisher (dsl.Publisher) ----------------------------------------

// KafkaPublisher publishes activity events fire-and-forget (async produce).
// Observability-grade delivery: a crash can drop buffered events. If some
// events become business-critical, implement dsl.Publisher over a
// transactional outbox in YOUR database instead — nothing else changes.
type KafkaPublisher struct {
	client *kgo.Client
}

func NewKafkaPublisher(brokers []string) (*KafkaPublisher, error) {
	client, err := kgo.NewClient(kgo.SeedBrokers(brokers...))
	if err != nil {
		return nil, err
	}
	return &KafkaPublisher{client: client}, nil
}

func (p *KafkaPublisher) Publish(ctx context.Context, topic string, key, value []byte) error {
	p.client.Produce(ctx, &kgo.Record{Topic: topic, Key: key, Value: value}, nil)
	return nil
}

func (p *KafkaPublisher) Close() { p.client.Close() }
