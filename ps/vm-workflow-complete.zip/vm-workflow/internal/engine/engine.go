// Package engine drives a dsl workflow tree across pods without owning
// any storage. Your existing database remains the only source of truth,
// accessed exclusively through YOUR retriever code (Loader/Lister).
//
// The engine keeps only in-memory scheduling hints (per-id "don't look
// before" times and retry counters). Losing them on a pod restart is
// harmless: the next tick re-lists in-flight ids, re-loads state through
// your retriever, re-walks the tree, and every workflow resumes exactly
// where your data says it stands. Worst case after a restart is one
// slightly-early re-check per workflow — never lost or corrupted work.
package engine

import (
	"context"
	"log/slog"
	"math"
	"sync"
	"time"

	"vmworkflow/internal/dsl"
	"vmworkflow/internal/lock"
)

// Loader is YOUR retriever: build the workflow state S for one id
// (hostname) from your existing tables/evidence fields. Called fresh on
// every walk — never cache S across cycles.
type Loader[S any] interface {
	Load(ctx context.Context, id string) (S, error)
}

// Lister is YOUR retriever for work discovery: return the ids of
// workflows that are currently in flight, judged from your existing data
// (e.g. rows whose status is neither operational nor failed).
type Lister interface {
	ListActive(ctx context.Context) ([]string, error)
}

type Config struct {
	LockTTL     time.Duration // ≥ 2× slowest single activity
	TickEvery   time.Duration // e.g. 5s
	Parallelism int           // concurrent walks per pod
	RetryBase   time.Duration // failure backoff base, e.g. 15s
	RetryMax    time.Duration // failure backoff cap, e.g. 10m
	MaxAttempts int           // consecutive failures before OnExhausted
}

type Engine[S any] struct {
	Tree   dsl.Node[S]
	Loader Loader[S]
	Lister Lister
	Locker lock.Locker
	Log    *slog.Logger
	Cfg    Config

	// OnDone fires once per pod when a walk finds the tree complete.
	// Optional: publish a summary event, write a completion status via
	// your own code, etc.
	OnDone func(ctx context.Context, id string, s S)
	// OnExhausted fires when an id has failed MaxAttempts times in a row
	// (per pod). Optional: publish a failure event, page someone. The id
	// keeps appearing via your Lister until YOUR data marks it inactive —
	// mark it failed in your tables here if you want it to stop.
	OnExhausted func(ctx context.Context, id string, lastErr error)

	mu    sync.Mutex
	sched map[string]entry // in-memory hints only; safe to lose
}

type entry struct {
	notBefore time.Time
	attempts  int
	lastErr   error
}

// Process walks one workflow once: lock → load fresh state via your
// retriever → walk the tree → schedule the next look.
func (e *Engine[S]) Process(ctx context.Context, id string) {
	if !e.due(id) {
		return
	}
	release, ok, err := e.Locker.TryAcquire(ctx, "wf:"+id, e.Cfg.LockTTL)
	if err != nil {
		e.Log.Error("lock error", "id", id, "err", err)
		return
	}
	if !ok {
		return // another pod owns it — normal
	}
	defer release(ctx)

	s, err := e.Loader.Load(ctx, id)
	if err != nil {
		e.Log.Error("retriever load failed", "id", id, "err", err)
		e.backoff(ctx, id, err)
		return
	}

	if e.Tree.Done(s) {
		e.Log.Info("workflow complete", "id", id)
		e.forget(id)
		if e.OnDone != nil {
			e.OnDone(ctx, id, s)
		}
		return
	}

	log := e.Log.With("id", id, "at", dsl.PathTo(e.Tree, s))
	res, err := e.Tree.Run(ctx, s)
	if err != nil {
		log.Warn("walk failed, backing off", "err", err)
		e.backoff(ctx, id, err)
		return
	}
	e.clearFailures(id)
	if res.RescheduleAfter > 0 {
		e.deferUntil(id, res.RescheduleAfter)
		log.Info("waiting", "recheck_in", res.RescheduleAfter)
		return
	}
	log.Info("progressed")
}

// Run is the per-pod loop: tick → your Lister → bounded concurrent walks.
// Blocks until ctx is cancelled; in-flight walks finish first.
func (e *Engine[S]) Run(ctx context.Context) {
	ticker := time.NewTicker(e.Cfg.TickEvery)
	defer ticker.Stop()
	sem := make(chan struct{}, e.Cfg.Parallelism)
	var wg sync.WaitGroup

	for {
		select {
		case <-ctx.Done():
			wg.Wait()
			return
		case <-ticker.C:
			ids, err := e.Lister.ListActive(ctx)
			if err != nil {
				e.Log.Error("retriever list failed", "err", err)
				continue
			}
			for _, id := range ids {
				if !e.due(id) {
					continue // waiting/backing off — skip cheaply
				}
				select {
				case sem <- struct{}{}:
				case <-ctx.Done():
					wg.Wait()
					return
				}
				wg.Add(1)
				go func(id string) {
					defer wg.Done()
					defer func() { <-sem }()
					e.Process(ctx, id)
				}(id)
			}
		}
	}
}

// --- in-memory scheduling hints -------------------------------------------

func (e *Engine[S]) due(id string) bool {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.sched == nil {
		return true
	}
	ent, found := e.sched[id]
	return !found || time.Now().After(ent.notBefore)
}

func (e *Engine[S]) deferUntil(id string, d time.Duration) {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.sched == nil {
		e.sched = map[string]entry{}
	}
	ent := e.sched[id]
	ent.notBefore = time.Now().Add(d)
	e.sched[id] = ent
}

func (e *Engine[S]) backoff(ctx context.Context, id string, cause error) {
	e.mu.Lock()
	if e.sched == nil {
		e.sched = map[string]entry{}
	}
	ent := e.sched[id]
	ent.attempts++
	ent.lastErr = cause
	d := time.Duration(float64(e.Cfg.RetryBase) * math.Pow(2, float64(ent.attempts-1)))
	if d > e.Cfg.RetryMax {
		d = e.Cfg.RetryMax
	}
	ent.notBefore = time.Now().Add(d)
	e.sched[id] = ent
	exhausted := e.Cfg.MaxAttempts > 0 && ent.attempts >= e.Cfg.MaxAttempts
	e.mu.Unlock()

	if exhausted && e.OnExhausted != nil {
		e.OnExhausted(ctx, id, cause)
	}
}

func (e *Engine[S]) clearFailures(id string) {
	e.mu.Lock()
	defer e.mu.Unlock()
	if ent, found := e.sched[id]; found {
		ent.attempts = 0
		ent.lastErr = nil
		e.sched[id] = ent
	}
}

func (e *Engine[S]) forget(id string) {
	e.mu.Lock()
	defer e.mu.Unlock()
	delete(e.sched, id)
}
