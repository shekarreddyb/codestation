> **Note:** the repo has since evolved to a schema-free variant — the workflow tree DSL over YOUR existing database via custom retrievers (see README). The concepts below (reconciliation, locks, CAS, idempotency, edge cases) all still apply; only the dedicated `vm_workflow` table is now optional.

# VM Operational Workflow — Design Reference

A code-based, storage-light workflow engine in Go for moving VMs to operational
status. No Temporal, no commercial workflow tools. State is derived from your
own database records via a custom resolver; execution is distributed across
pods using distributed locks.

---

## 1. Problem Summary

- **Trigger:** Kafka message or HTTP API call carrying a VM `hostname`.
- **Flow:** series of steps — call external APIs, submit scans, poll for
  results, remove build privileges, more API calls, poll again → operational.
- **Constraints:**
  - No Temporal / commercial workflow engines.
  - Custom logic decides the current stage by querying DB records.
  - Runs across multiple pods (Kubernetes) → needs distributed coordination.
  - Stack: **Redis** (available), **YugabyteDB** (no `pg_advisory_lock`,
    limited `SKIP LOCKED` support → table-based lease locks).

---

## 2. Core Architecture

Three small components. The stage is **always derived, never trusted from
memory** — this is what makes the system crash-safe without a workflow store.

```
Kafka consumer ─┐
                ├─► enqueue/upsert VM record ──► [Yugabyte: vm_workflow table]
HTTP endpoint ──┘                                          ▲
                                                           │ read/CAS write
        ┌──────────────── per pod ─────────────────┐       │
        │  Ticker → Claim loop → Lock(hostname)    │       │
        │        → Resolver → Stage registry       │───────┘
        │        → run ONE unit of work → return   │
        └──────────────────────────────────────────┘
```

### 2.1 Resolver (your custom logic)

Pure decision function: reads the record(s), returns the stage. No side
effects. Re-resolved fresh on every cycle.

```go
type Stage string

const (
    StageSubmitScan  Stage = "submit_scan"
    StageAwaitScan   Stage = "await_scan"
    StageRemovePrivs Stage = "remove_privs"
    StageFinalize    Stage = "finalize"
    StageAwaitFinal  Stage = "await_final"
    StageDone        Stage = "done"
    StageFailed      Stage = "failed"
)

func ResolveStage(ctx context.Context, db *sql.DB, hostname string) (Stage, error) {
    rec, err := loadRecord(ctx, db, hostname)
    if err != nil {
        return "", err
    }
    switch {
    case rec.Attempts > maxAttempts:
        return StageFailed, nil
    case rec.ScanID == "":
        return StageSubmitScan, nil
    case rec.ScanStatus != "complete":
        return StageAwaitScan, nil
    case rec.HasBuildPrivs:
        return StageRemovePrivs, nil
    case !rec.FinalCallsDone:
        return StageFinalize, nil
    case rec.FinalStatus != "ok":
        return StageAwaitFinal, nil
    default:
        return StageDone, nil
    }
}
```

### 2.2 Stage registry

One idempotent handler per stage. Each handler performs **one unit of work**,
updates the record, and returns. Polling stages check once and reschedule —
no goroutine ever sleeps holding workflow state.

```go
type StageHandler func(ctx context.Context, db *sql.DB, hostname string) error

var registry = map[Stage]StageHandler{
    StageSubmitScan:  submitScan,
    StageAwaitScan:   checkScanOnce,   // poll once; if pending, bump next_check_at
    StageRemovePrivs: removeBuildPrivileges,
    StageFinalize:    finalizeCalls,
    StageAwaitFinal:  checkFinalOnce,
}
```

### 2.3 Driver loop (per pod)

```go
func Process(ctx context.Context, hostname string) error {
    lock, err := locker.Obtain(ctx, "vmwf:"+hostname, 2*time.Minute)
    if err == redislock.ErrNotObtained {
        return nil // another pod owns it — normal, not an error
    }
    if err != nil {
        return err
    }
    defer lock.Release(ctx)

    stage, err := ResolveStage(ctx, db, hostname)
    if err != nil || stage == StageDone || stage == StageFailed {
        return err
    }
    if err := registry[stage](ctx, db, hostname); err != nil {
        return recordFailure(ctx, db, hostname, err) // attempts++, backoff next_check_at
    }
    return nil
}
```

Scheduler: `time.Ticker` per pod → claim query → `Process` each claimed
hostname (bounded worker pool, e.g. `errgroup.SetLimit`).

---

## 3. Data Model (Yugabyte)

```sql
CREATE TABLE vm_workflow (
    hostname        TEXT PRIMARY KEY,
    -- domain state your resolver reads:
    scan_id         TEXT,
    scan_status     TEXT,
    has_build_privs BOOLEAN NOT NULL DEFAULT true,
    final_calls_done BOOLEAN NOT NULL DEFAULT false,
    final_status    TEXT,
    -- scheduling / observability:
    next_check_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    attempts        INT NOT NULL DEFAULT 0,
    last_error      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_vmwf_due ON vm_workflow (next_check_at)
    WHERE scan_status IS DISTINCT FROM 'done';
```

**Claim query** (Yugabyte-safe, no SKIP LOCKED dependency — Redis lock does
mutual exclusion; this just finds due work):

```sql
SELECT hostname FROM vm_workflow
WHERE next_check_at <= now()
  AND stage_terminal = false          -- or equivalent predicate
ORDER BY next_check_at
LIMIT 20;
```

Multiple pods may select overlapping rows; the per-hostname Redis lock
deduplicates execution. Losing the lock race is cheap and expected.

**`next_check_at` is the scheduler.** 
- Poll stage still pending → `next_check_at = now() + poll_interval`.
- Handler failed → `next_check_at = now() + base * 2^attempts` (cap it).
- Stage advanced → `next_check_at = now()` (make progress immediately).

---

## 4. Distributed Locking

### Option A — Redis (recommended, you have it)

Library: `github.com/bsm/redislock`.

- `Obtain` with TTL ≥ 2× your slowest single stage (stages are short by
  design — one API call / one poll check).
- Use `lock.Refresh` (heartbeat) only if a stage can legitimately run long.
- Redis locks are *advisory and can expire early* (GC pause, network stall).
  Correctness therefore does **not** rest on the lock — it rests on
  idempotent handlers + CAS writes (below). The lock is an efficiency
  mechanism to avoid duplicate work, not the safety mechanism.

### Option B — Yugabyte table lease (no extra infra)

```sql
CREATE TABLE locks (
    resource   TEXT PRIMARY KEY,
    owner      TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL
);

-- acquire (won if rows affected = 1):
INSERT INTO locks (resource, owner, expires_at)
VALUES ($1, $2, now() + interval '2 minutes')
ON CONFLICT (resource) DO UPDATE
SET owner = EXCLUDED.owner, expires_at = EXCLUDED.expires_at
WHERE locks.expires_at < now();

-- release (only if still owner):
DELETE FROM locks WHERE resource = $1 AND owner = $2;

-- renew (heartbeat):
UPDATE locks SET expires_at = now() + interval '2 minutes'
WHERE resource = $1 AND owner = $2;
```

Check `RowsAffected()` on acquire/release/renew. `owner` = pod name + random
suffix so a pod never frees another pod's lock.

### The real safety net: check-and-set (CAS) record writes

Every handler write includes the expected prior state in the `WHERE` clause:

```sql
UPDATE vm_workflow
SET scan_id = $2, scan_status = 'submitted', updated_at = now()
WHERE hostname = $1 AND scan_id IS NULL;   -- expected prior state
```

If `RowsAffected() == 0`, another worker already advanced this VM (stale lock
holder scenario) → abort quietly. This makes double-execution harmless even
when locks misbehave.

---

## 5. Suggested Libraries

| Concern | Library | Notes |
|---|---|---|
| DB driver | `github.com/jackc/pgx/v5` | Yugabyte speaks the Postgres wire protocol. Use `pgxpool`. |
| Redis lock | `github.com/bsm/redislock` | Simple TTL lock + Refresh. (`go-redsync/redsync` if multi-node Redlock needed.) |
| Redis client | `github.com/redis/go-redis/v9` | Required by redislock. |
| Kafka | `github.com/twmb/franz-go` | Modern, pure Go, solid consumer groups. (`segmentio/kafka-go` = simpler alternative.) |
| Retry/backoff | `github.com/cenkalti/backoff/v4` | Context-aware exponential backoff for API calls. |
| Retryable HTTP | `github.com/hashicorp/go-retryablehttp` | If you prefer retries baked into the HTTP client. |
| Worker pool | `golang.org/x/sync/errgroup` | `SetLimit(n)` bounds concurrency in the claim loop. |
| FSM (optional) | `github.com/qmuntal/stateless` | Only if the flow branches. External-storage mode fits the resolver model; exports DOT graphs. Skip for linear flows. |
| Logging | `log/slog` (stdlib) | Structured logs keyed by hostname + stage. |
| Metrics | `github.com/prometheus/client_golang` | Stage counts, durations, stuck-VM gauge. |

**Deliberately avoided:** `cschleiden/go-workflows`, `luno/workflow`,
`looplab/fsm` — each owns workflow state internally, which conflicts with the
"my resolver derives the stage from my records" requirement.

---

## 6. Kafka & API Ingestion

- Both entry points do the same tiny thing: **upsert the VM record**
  (`INSERT ... ON CONFLICT (hostname) DO NOTHING` or reset for re-runs) and
  return. All real work happens in the driver loop.
- Kafka: commit the offset **after** the upsert succeeds (at-least-once).
  Duplicate messages are harmless because the upsert is idempotent.
- Do **not** run the whole workflow inside the Kafka handler — long polling
  inside a consumer causes rebalance storms. Consume → upsert → commit.
- HTTP endpoint returns `202 Accepted` + a status URL immediately.

---

## 7. Edge Cases & How This Design Handles Them

1. **Pod crash mid-workflow** — stage is re-derived from the record on the
   next claim cycle. Nothing lost. (This is the core payoff of the pattern.)
2. **Crash between external API call and DB write** — handler re-runs; it
   must first *check* the external system (e.g., query scan API by hostname
   or use an idempotency key) before re-submitting. Every handler follows
   *check → act → record*.
3. **Lock expires while handler still running** — CAS write fails
   (`RowsAffected == 0`) → abort. No corruption.
4. **Two pods claim the same hostname** — one wins the lock; the loser skips.
5. **Duplicate Kafka delivery / duplicate API request** — upsert is
   idempotent; workflow already in flight just continues.
6. **External API down** — handler returns error → `attempts++`,
   `next_check_at` backs off exponentially, `last_error` recorded.
7. **Poison VM (never succeeds)** — `attempts > maxAttempts` → resolver
   returns `StageFailed`; alert on it; manual requeue = reset `attempts`.
8. **Stuck workflow (scan never completes)** — add a per-stage or overall
   deadline column; resolver routes to `StageFailed`/escalation when
   `now() > deadline`. Also alert on `updated_at` older than N hours.
9. **Operator manual fix** — patch the record in Yugabyte; resolver derives
   the corrected stage next cycle. No engine state to reconcile.
10. **Re-running an already-operational VM** — decide policy explicitly:
    reject at ingestion, or reset the record fields to restart the flow.
11. **Clock skew across pods** — lease locks compare `expires_at` against
    *DB server* `now()`, not pod clocks; Redis TTLs are Redis-side. Keep all
    time math in one place.
12. **Thundering herd after downtime** — claim query `LIMIT` + errgroup
    limit + jitter on `next_check_at` naturally smooth the backlog.
13. **Slow poll targets starving fast ones** — `ORDER BY next_check_at`
    keeps fairness; optionally separate poll intervals per stage.

---

## 8. Best Practices Checklist

- [ ] **Never cache the stage in memory.** Resolve fresh every cycle.
- [ ] **One unit of work per handler invocation**; scheduling via
      `next_check_at`, never `time.Sleep` for long waits.
- [ ] **Idempotent handlers**: check external state before acting;
      idempotency keys on submit-style APIs where supported.
- [ ] **CAS on every record write** (expected prior state in `WHERE`).
- [ ] **TryLock semantics**: failing to get a lock is a skip, not an error.
- [ ] **Context deadlines** on every external call (`ctx` with per-call
      timeout, e.g. 10–30 s) so a hung API can't outlive the lock.
- [ ] **Bounded concurrency** per pod (`errgroup.SetLimit`).
- [ ] **Backoff with jitter** on retries; cap the maximum interval.
- [ ] **Structured logging** with `hostname`, `stage`, `attempt` on every
      line — this is your request tracing.
- [ ] **Metrics**: per-stage counters/durations, in-flight gauge,
      stuck-VM gauge (`updated_at` age), lock-contention counter.
- [ ] **Status endpoint**: `GET /vms/{hostname}` → record + derived stage;
      `GET /vms?active=true` → in-flight list. Tracking comes free from the
      table.
- [ ] **Terminal states are explicit** (`done`, `failed`) — resolver must
      always return *something*, never loop forever silently.
- [ ] **Graceful shutdown**: on SIGTERM stop claiming new work, finish the
      in-flight handler (they're short), release locks.
- [ ] **Test the resolver as a pure function** — table-driven tests mapping
      record states → expected stage. This is where most bugs will live.
- [ ] **Chaos-test the CAS path**: run two workers on one hostname with the
      lock disabled and verify no double-submit / no corruption.

---

## 9. What NOT to Do

- Don't hold a goroutine sleeping for the duration of a scan.
- Don't run workflow logic inside the Kafka consumer callback.
- Don't trust the lock alone for correctness — it's an optimization.
- Don't store "current stage" as authoritative and skip re-derivation;
  the moment you do, you've built a fragile workflow store.
- Don't add a workflow framework on top; the whole engine here is
  ~200–300 lines and stays debuggable with a stack trace and a SQL query.

---

## 10. Rough Component Layout (repo structure)

```
cmd/
  worker/main.go        # ticker + claim loop + worker pool
  api/main.go           # HTTP ingestion + status endpoints (can be same binary)
internal/
  ingest/kafka.go       # franz-go consumer → upsert
  ingest/http.go        # POST /vms → upsert, GET /vms/{hostname} → status
  workflow/resolver.go  # ResolveStage (pure, unit-tested)
  workflow/stages.go    # Stage constants + registry
  workflow/handlers/    # one file per stage handler
  workflow/driver.go    # Process(): lock → resolve → dispatch
  store/records.go      # loadRecord, CAS updates, claim query
  store/locks.go        # Redis lock wrapper (or table lease impl)
  clients/              # external API clients with retryablehttp/backoff
```
