# VM Onboarding Workflow — Technical Documentation

## 1. Architecture

```
Kafka consumer ──► Registrar (your write) ──┐
REST POST /vms ──► Registrar (your write) ──┤
                                            ▼
                              YOUR EXISTING DATABASE
                          (statuses, IDs, evidence fields)
                                   ▲            ▲
                     Loader (read) │            │ persist* (your
                     Lister (read) │            │ conditional writes)
        ┌────────── per pod ───────┴────────────┴──────────┐
        │ tick → Lister → due? → Redis try-lock(hostname)  │
        │      → Loader → walk Tree → run ONE unit of work │
        │      → in-memory schedule hint → return          │
        └───────────────────────────────────────────────────┘
                          │
                          ▼ (per wrapped activity)
                 Kafka events topic (started/succeeded/failed/rescheduled)
```

Principles:

1. **No owned storage.** The engine adds no tables. All reads go through
   your retriever (`Loader`/`Lister`); all writes happen inside your
   activity/persist code. In-memory state is limited to scheduling hints
   that are safe to lose.
2. **Derived position.** The workflow's position is never stored — it is
   re-derived on every cycle by walking the tree against freshly loaded
   state. This is what makes restarts free.
3. **One unit of work per walk.** No goroutine ever sleeps waiting on an
   external system; waits are expressed as reschedule hints.

## 2. Package map

| Package | Role | Edit? |
|---|---|---|
| `internal/dsl` | Generic workflow tree: Node[S], containers, events decorator. No DB or domain knowledge. | rarely |
| `internal/engine` | Stateless driver: list → lock → load → walk. In-memory backoff/schedule. | rarely |
| `internal/lock` | `Locker` interface; Redis try-lock (bsm/redislock); local locker for tests. | rarely |
| `internal/vmflow` | **Your domain**: `State`, retrievers, persist methods, the `Tree`. | yes |
| `internal/clients` | External API interfaces (Scan/Change/Privs/SNOW). | yes |
| `internal/ingest` | Kafka consumer (register→commit), HTTP API, Kafka event publisher. | lightly |
| `cmd/server` | Wiring and config. | lightly |

## 3. DSL reference

All nodes implement `Node[S]`: `Name()`, `Done(s) bool` (pure — judged
only from S), `Run(ctx, s) (Result, error)` (one unit of work).
`Result.RescheduleAfter > 0` means "walk me again after this delay".

| Node | Semantics |
|---|---|
| `Activity(name, done, run)` | Leaf. `run` must follow **check → act → record**: query the external system first, act only if needed, persist through your code. |
| `Poll(name, every, done, check)` | Leaf for waiting. `check` inspects the external system once; when ready it persists the outcome (making `done` true next walk). Not ready → `Wait(every)`. |
| `Sequence(name, children...)` | Runs the first not-done child per walk; done when all done. |
| `If(name, cond, then, els)` | Branch on `cond(S)`; `els` may be nil (skip). |
| `Switch(name, default, cases...)` | N-way If (e.g. per-OS privilege removal). First matching `When` wins. |
| `Parallel(name, children...)` | Fork/join: each walk runs ALL not-done children concurrently; done when all done. Branch errors are joined; siblings aren't cancelled; only failed branches re-run next walk. Reschedule = smallest branch wait. |
| `While(name, cond, body)` | Repeats body while `cond(S)`; iteration progress MUST live in your data. Errors if body is done while cond still true (guards infinite spin). |
| `Events{...}.Wrap(node)` | Decorator: publishes started before Run, then succeeded/failed/rescheduled. `Done()` passes through — skipped walks emit nothing. Publish failures are logged, never fail the workflow. |
| `PathTo(node, s)` | Breadcrumb of the first incomplete node, e.g. `vm-onboarding/scans_good/proceed/await_cr_implement`. |

### DSL invariants (breaking these breaks restart-safety)

- `Done` and conditions perform **no I/O** and read only S.
- Decisions from volatile data (API responses) are persisted by an
  activity first; conditions read the persisted value on the next walk.
- Loop/branch progress is derivable from your data, per branch (parallel
  scans each have their own ID/status fields).

## 4. Engine internals

`Engine[S]` fields: `Tree`, `Loader`, `Lister`, `Locker`, `Cfg`, optional
`OnDone` / `OnExhausted` hooks.

Cycle (`Run`): ticker (`TickEvery`, default 5s) → `Lister.ListActive`
(your query = the work queue) → for each id not deferred in memory →
bounded goroutine pool (`Parallelism`) → `Process(id)`.

`Process(id)`:
1. In-memory `due` check (skip if deferred/backing off).
2. `Locker.TryAcquire("wf:"+id, LockTTL)` — not obtained = silent skip.
3. `Loader.Load(id)` — fresh state, never cached.
4. `Tree.Done(s)` → `OnDone`, forget id, return.
5. `Tree.Run(ctx, s)`:
   - error → in-memory attempts++, exponential backoff
     (`RetryBase * 2^(attempts-1)`, capped at `RetryMax`); at
     `MaxAttempts` consecutive failures → `OnExhausted` (persist a
     terminal failure there so your Lister drops the id).
   - `RescheduleAfter > 0` → defer id in memory.
   - else → progressed; attempts reset.

In-memory hints (`notBefore`, `attempts`) are per pod and disposable:
after a restart every active id is simply re-walked once, and polls
re-issue one early check. Nothing is lost or duplicated *in your data*
because activities are idempotent and writes are conditional.

## 5. Locking & multi-pod correctness

- Per-hostname **try-lock** in Redis (`bsm/redislock`), TTL ≥ 2× the
  slowest single activity. Losing the race is a normal skip.
- The lock is an **efficiency** mechanism. Correctness rests on:
  - idempotent activities (check → act → record), and
  - your conditional writes (`UPDATE ... WHERE <expected prior state>`,
    treating 0 rows affected as "another worker advanced — abort quietly").
- Therefore a lock expiring mid-activity (GC pause, slow API) cannot
  corrupt state; worst case is a duplicate external *read* or a benign
  re-submit caught by the check step.

## 6. Ingestion

- Kafka: consumer group, manual commits. Order is strict:
  `Register` (your idempotent write) **then** commit. Malformed messages
  are logged and committed past (poison-message handling). Registration
  failures are not committed → redelivered.
- REST: `POST /vms` registers, returns 202 + status URL, and kicks one
  engine walk immediately on a detached 30s context so step 1 starts
  without waiting for the next tick.

## 7. Configuration (env)

| Var | Default | Notes |
|---|---|---|
| `DATABASE_URL` | — | your existing DB (pgx DSN; Yugabyte = PG wire) |
| `REDIS_ADDR` / `REDIS_PASSWORD` | `localhost:6379` / — | lock backend |
| `KAFKA_BROKERS` | empty = Kafka disabled | comma-separated |
| `KAFKA_TOPIC` / `KAFKA_GROUP` | `vm-workflow` / `vm-workflow-workers` | request ingestion |
| `EVENTS_TOPIC` | `vm-workflow-events` | activity events |
| `HTTP_ADDR` | `:8080` | |

Engine tuning lives in `cmd/server/main.go` (`engine.Config`): LockTTL
2m, TickEvery 5s, Parallelism 8, RetryBase 15s, RetryMax 10m,
MaxAttempts 10.

## 8. Adaptation guide (in order)

1. `vmflow.State` — mirror your real columns/evidence fields.
2. `Retriever.Load` / `ListActive` / `Register` — your SQL against your
   existing tables (stubs show intended shape). `ListActive` must exclude
   completed and failed workflows.
3. `persist*` methods in `tree.go` — conditional writes with expected
   prior state in the WHERE clause.
4. `internal/clients` — real API clients. Recommended: per-call ~15s
   context timeout + `cenkalti/backoff` for transient 5xx,
   `backoff.Permanent` for 4xx.
5. Tree shape — add/remove/reorder activities; wrap event-worthy ones.
6. `OnExhausted` — persist terminal failure + alert.

## 9. Testing strategy

- `internal/dsl/dsl_test.go` demonstrates the pattern: fake state +
  recording activities; covers sequence ordering, branching, parallel
  fork/join, partial-failure retry isolation, poll rescheduling, event
  emission, breadcrumbs. Extend the same way for your tree using fake
  clients and a fake retriever.
- The tree with real client fakes gives full workflow simulation without
  any infrastructure (use `lock.NewLocalLocker()`).
- Chaos check worth automating: run two engines over one fake store with
  locking disabled and assert no double-submits — this validates your
  check-and-persist discipline, which is the real safety net.

## 10. Edge cases & resolutions

| Case | Resolution |
|---|---|
| Pod crash mid-activity | Next walk re-derives position; activity's CHECK step prevents double external submission. |
| All pods restart simultaneously | Nothing lost: Lister re-lists, tree re-walks. Kafka requests buffer at the broker. Orphaned Redis locks expire via TTL (≤ LockTTL delay). |
| Lock expires while activity runs | Conditional write loses (0 rows) → quiet abort; no corruption. |
| Two pods pick the same hostname | One wins the lock; the other skips at near-zero cost. |
| Duplicate Kafka delivery | `Register` idempotent → no-op. |
| CR stuck in approval forever | Add an overall deadline field to your data; the CR poll already fails terminal CR states (rejected/cancelled). Alert on stale `updated_at`. |
| Bad scans | If-branch persists terminal failure + event; CR never created. |
| Unknown OS type | Switch default branch errors → backoff → exhausted → alert (fix data, re-queue). |
| Poison workflow | `MaxAttempts` → `OnExhausted`; keep appearing in Lister until your data marks it failed — persist that in the hook. |
| Thundering herd after downtime | Bounded parallelism + tick pacing; per-pod jitter can be added to the ticker if needed. |

## 11. Dependencies

`jackc/pgx/v5` (DB), `bsm/redislock` + `redis/go-redis/v9` (locks),
`twmb/franz-go` (Kafka), `cenkalti/backoff/v4` (client retries),
stdlib `log/slog` (logging). Run `go mod tidy` once in your environment
to generate `go.sum`.
